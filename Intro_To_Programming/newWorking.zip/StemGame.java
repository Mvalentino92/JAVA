import java.util.Scanner;
public class StemGame
{
	static Scanner input = new Scanner(System.in);
	static String[] yes = {"ye","yeh","ya","yea","yeah","yes","sure","absolutely","fine","okay","ok"};
	static String[] no = {"Come on, just do it, say yes: ","If you want to continue you sort of have to say yes: ","I\'m not going to ask again. "
		+"(Well I will becaue it\'s a while loop), but just say yes: ","Who says no? Honestly. Don\'t you want to keep playing? Just say yes: ","Look. "
			+"The game can\'t go on until you say yes. So just say it: ","If you say yes I\'ll give you free HP: ","Hurry up and say yes already: "};
	public static void display(String message)
	{
		System.out.print(message);
		input.nextLine();
	}

	public static void displayln(String message)
	{
		System.out.print(message);
		input.nextLine();
		System.out.println();
	}

	public static void promptYesOrNo(String message)
	{
		String[] response = new String[25];
		int count = 0;
		boolean saidYes = false;
		System.out.print(message);
		Scanner readResponse = new Scanner(System.in);
		while(true)
		{
			String userResponse = input.nextLine();
			readResponse = new Scanner(userResponse);
			while(readResponse.hasNext())
			{
				response[count++] = readResponse.next();
			}
			//Check against the string
			for(int i = 0; i < count; i++)
			{
				for(int j = 0; j < yes.length; j++)
				{
					if(response[i].equalsIgnoreCase(yes[j]) || response[i].regionMatches(true,0,"yes",0,3)) saidYes = true;
				}
			}
			count = 0;
			if(saidYes) 
			{
				readResponse.close();
				break;
			}
			else
			{
				int reAsk = (int)(Math.random()*no.length);
				System.out.print(no[reAsk]);
			}
		}
	}

	public static void main(String[] args)
	{
		//Creating all the professor
		Farnum farnum = new Farnum();
		Joiner joiner = new Joiner();
		Hayes hayes = new Hayes();
		Merrit merrit = new Merrit();
		Nan nan = new Nan();
		Cuesta cuesta = new Cuesta();
		Coniglio coniglio = new Coniglio();
		Baldwin balwin = new Baldwin();
		R r = new R();

		System.out.print("Welcome to STEM Survival!~");
		input.nextLine();
		System.out.print("Your task is the traverse the floors of the STEM building, and face the professors in academic battle!~");
		input.nextLine();
		System.out.print("Before we begin, you must pick a major. I\'ll list the available majors below.~");
		input.nextLine();

		//Setting the inital defeated and victorious variables, and having the user select a major.
		boolean defeated = false;
		boolean victory = false;
		int major = misc.chooseMajor();
		Student player;
		if(major == 1) player = new MathEducation();
		else if(major == 2) player = new BioEducation();
		else if(major == 3) player = new ChemEducation();
		else if(major == 4) player = new BioTechnology();
		else if(major == 5) player = new CompMath();
		else if(major == 6) player = new Engineering();
		else if(major == 7) player = new BioMedicine();
		else if(major == 0) player = new Wilson();
		else player = new Student();

		//If the user didn't unlock Evan Wilson, ask for their name and give initial items
		if(!player.name.equals("Evan Wilson"))
		{
			System.out.print("What is your name?: ");
			String playerName = game.input.nextLine();
			player.name = playerName;
		}

		//Begin the outer while loop, that will keep track of if the player wins or loses
		while(!defeated && !victory)
		{
			System.out.printf("Well hello %s, it\'s nice to meet you. And I\'m glad you decided to join the program!~",player.name);
			input.nextLine();
			System.out.print("Since college starts out pretty tough, I\'d like to give you a few gifts to get you started.~");
			input.nextLine();
			System.out.printf("%s gained a Pretzel!~",player.name);
			input.nextLine();
			System.out.printf("%s gained a RedBull!~",player.name);
			input.nextLine();
			display("I suppose first I should give you a tour of the building.~");
			display("We\'ll start on the first floor and...WHOAH!~");
			display("Did you hear that?!?!: ");
			display("What, say that again. I can\'t hear you over the clamour?!: ");
			display("One more time, the noise is too loud: ");
			display("Okay, this isn\'t working. Lets just go check it out.~");
			display("It sounds like it\'s coming from the autoclave room.~");
			promptYesOrNo("Do you want to go check it out?: ");
			display("Sweet! Let\'s go!~");
			display("**You see a lot of smoke coming from the autoclave room**~");
			display("**You see a figure, but you can\'t quite make out who it is**~");
			display("**You think to yourself \"The autoclave is definitely broken, but who could be fixing it?**\"~");
			display("**You begin to take a step forward to investigate....**~");
			displayln(player.name+" watch out! There\'s only one person in this building who can fix the autoclave!!~");
			displayln("!!You are challenged by Nan!!~");
			
			//First battle with Nan
			if(player instanceof BioTechnology || player instanceof BioMedicine)
			{
				display("Nan has high knowledge of your major!~");
				displayln("Your attacks are reduced in power for this battle!~");
				player.setScale(true,0.85);
			}
			player.setScaleDisplay();
			while(player.HP > 0 || player.hasAppeal)
			{
				player.printStats(nan);
				int attackCode = attacks.initialCommand();
				attackCode = attacks.hasGPA(player,attackCode);
				System.out.println();
				attacks.studentAttack(player,nan,attackCode);
				input.nextLine();
				input.nextLine();
				System.out.println();
				if(nan.HP <= 0) 
				{
					System.out.print("\nYou defeated "+nan.name+"~");
					input.nextLine();
					break;
				}
				attacks.professorAttack(player,nan);
				if(player.HP <= 0 && player.hasAppeal)
				{
					System.out.print("\n\n"+nan.name+" defeated you!~");
					input.nextLine();
					System.out.print("But wait! You were given a second chance during appeals!~");
					player.HP = player.maxHP/2;
					player.hasAppeal = false;
				}
				player.inBathroom = false;
				input.nextLine();
				System.out.println();
			}
			if(player.HP <= 0)
			{
				display("\n"+nan.name+" defeated you!~");		
				defeated = true;
				continue;
			}
			//End battle with Nan

			//Start Nans minigame, and prompt for the store if possible. Re-set stats afterwards
			display("Great job defeating "+nan.name+"!~");
			displayln("But you aren\'t done yet. It\'s time for your exam!~");
			minigames.defeatedNan(player);
			System.out.print("");
			display("Now before we continue, you should buy an item from the store.~");
			displayln("Or at least look at the wares, might not be a bad idea.~");
			System.out.print("");
			Items.shop(player);
			display("Before we continue, (inevitably towards a next battle), you should consider using an item.~");
			Items.useInventory(player,nan);
			display("Okay, onward!~");
			System.out.print("");
			display("We should go check out the front desk on the second floor, see if anyone is there.~");
			display("**You take the stairs, yes the STAIRS to the second floor**~");
			display("Hmmm, do you see that backpack over by the front desk "+player.name+"?~");
			promptYesOrNo("You want to go check out and see who\'s it is?: ");
			display("**You walk over and see a bunch of papers around the backpack in a pile**~");
			display("**You see a lot of red ink on some of the papers, as it appears someone was in the process of grading these**~");
			display("**Upon further inspection, the papers seem to be on Physics..but this doesn\'t look like Dr.Joiners work**~");
			display("**If it\'s not Dr.Joiners, who else could be teaching physics?~");
			display("Wait! "+player.name+" be careful! Those are high school physics tests!~");
			displayln("That means they must belong to...~");
			displayln("!!You are challenged by Professor Cuesta!!~");

			
			//Set default stats, and reduce if necessary, and reset the display
			if(player instanceof BioTechnology || player instanceof ChemEducation)
			{
				display("Professor Cuesta has high knowledge of your major!~");
				displayln("Your attacks are reduced in power for this battle!~");
				player.setScale(true,0.85);
			}
			player.setScaleDisplay();
			while(player.HP > 0 || player.hasAppeal)
			{
				player.printStats(cuesta);
				int attackCode = attacks.initialCommand();
				attackCode = attacks.hasGPA(player,attackCode);
				System.out.println();
				attacks.studentAttack(player,cuesta,attackCode);
				input.nextLine();
				input.nextLine();
				System.out.println();
				if(cuesta.HP <= 0) 
				{
					System.out.print("\nYou defeated "+cuesta.name+"~");
					input.nextLine();
					break;
				}
				attacks.professorAttack(player,cuesta);
				if(player.HP <= 0 && player.hasAppeal)
				{
					System.out.print("\n\n"+cuesta.name+" defeated you!~");
					input.nextLine();
					System.out.print("But wait! You were given a second chance during appeals!~");
					player.HP = player.maxHP/2;
					player.hasAppeal = false;
				}
				player.inBathroom = false;
				input.nextLine();
				System.out.println();
			}
			if(player.HP <= 0)
			{
				display("\n"+cuesta.name+" defeated you!~");		
				defeated = true;
				continue;
			}

			//Cuesta gets PHD and set default stats
			cuesta.getPHD();

			//End battle with Cuesta and continue story
			display("Another great victory!~");
			display("So great in fact that you leveled up!~");
			displayln("Pick your increase carefully, who knows how many more times you\'ll level up (I sure don\'t, kind of just winging it)~");
			player.levelUp();
			player.setDefaultStats();
			display("Perfect, you\'re well on your way to beating the game! (maybe)~");
			input.nextLine();
			display("Isn\'t leveling up so fun..so exhilarating?~");
			display("You know what isn\'t?~");
			displayln("Taking another exam!~");
			minigames.defeatedCuesta(player);
			System.out.print("");
			Items.shop(player);
			Items.useInventory(player,nan);
			display("Okay, we all good to continue now? Great, lets go!~");
			display("Hmmm, where to next?~");
			display("I mean I guess it would make sense to just go up a floor and see what\'s going on there.~");
			display("Would you like the take the elevator or the stairs?: ");
			display("I agree, the stairs are awesome and you should always take them unless your going up literally, 15 floors.~");
			display("**Right after coming up the stairs, you notice the door straight ahead is open**~");
			display("I see you eyeing that classroom "+player.name+"~");
			promptYesOrNo("Want to check it out?: ");
			display("**You walk into the classroom and see an open laptop**~");
			display("**Because your nosy, you decide to check out the webpage that\'s open**~");
			display("**It\'s something called OWL, and seems some sort of online question tool**~");
			display("**You see a bunch of chapters, and for some reason all your insticts are telling you to click \"start\" for all of them.~");
			display("**Slowly but surely you begin to move the mouse over to click \"start\"~");
			display("NOOOOOOOOOOOOO!!!! Don\'t click \"start\" "+player.name+"~");
			displayln("It\'ll mess everything up and Dr....~");
			displayln("!!You are challenged by Dr.R!!~");

			//Start battle with Dr.R
			if(player instanceof BioMedicine || player instanceof ChemEducation)
			{
				display("Dr.R has high knowledge of your major!~");
				displayln("Your attacks are reduced in power for this battle!~");
				player.setScale(true,0.85);
			}
			player.setScaleDisplay();
			while(player.HP > 0 || player.hasAppeal)
			{
				player.printStats(r);
				int attackCode = attacks.initialCommand();
				attackCode = attacks.hasGPA(player,attackCode);
				System.out.println();
				attacks.studentAttack(player,r,attackCode);
				input.nextLine();
				input.nextLine();
				System.out.println();
				if(r.HP <= 0) 
				{
					System.out.print("\nYou defeated "+r.name+"~");
					input.nextLine();
					break;
				}
				attacks.professorAttack(player,r);
				if(player.HP <= 0 && player.hasAppeal)
				{
					System.out.print("\n\n"+r.name+" defeated you!~");
					input.nextLine();
					System.out.print("But wait! You were given a second chance during appeals!~");
					player.HP = player.maxHP/2;
					player.hasAppeal = false;
				}
				player.inBathroom = false;
				input.nextLine();
				System.out.println();
			}
			if(player.HP <= 0)
			{
				display("\n"+r.name+" defeated you!~");		
				defeated = true;
				continue;
			}

			//End battle with Dr.R, shop, inventory, continue story, reset Stats
			player.setDefaultStats();
			display("You are getting pretty good at this "+player.name+"~");
			display("I know you never got a chance to do some of that OWL, but it might\'ve come in handy...~");
			displayln("Exam time!~");
			minigames.defeatedR(player);
			System.out.print("");
			Items.shop(player);
			Items.useInventory(player,nan);
			display("Alright, let\'s keep it moving, we still have a lot of ground to cover.~");
			display("Matter of fact, our next move is up to you.~");
			display("Where do you want to go next?: ");
			display("Say it again, I can\'t hear you over that music: ");
			display("Okay, I\'m not doing this again!~");
			display("Who is playing loud rock music right now!~");
			display("Ya know what, let\'s go check it out!~");
			display("I wanna give this person a piece of my mind!~");
			display("**You rush over to room 324 (I think, idk the one with the glass doors)**~");
			displayln("**As soon as you enter the room..**~");
			displayln("!!You are challenged by Dr.Hayes!!~");

			//Begin battle with Dr.Hayes
			if(player instanceof BioTechnology || player instanceof BioEducation)
			{
				display("Dr.Hayes has high knowledge of your major!~");
				displayln("Your attacks are reduced in power for this battle!~");
				player.setScale(true,0.85);
			}
			player.setScaleDisplay();
			while(player.HP > 0 || player.hasAppeal)
			{
				player.printStats(hayes);
				int attackCode = attacks.initialCommand();
				attackCode = attacks.hasGPA(player,attackCode);
				System.out.println();
				attacks.studentAttack(player,hayes,attackCode);
				input.nextLine();
				input.nextLine();
				System.out.println();
				if(hayes.HP <= 0) 
				{
					System.out.print("\nYou defeated "+hayes.name+"~");
					input.nextLine();
					break;
				}
				attacks.professorAttack(player,hayes);
				if(player.HP <= 0 && player.hasAppeal)
				{
					System.out.print("\n\n"+hayes.name+" defeated you!~");
					input.nextLine();
					System.out.print("But wait! You were given a second chance during appeals!~");
					player.HP = player.maxHP/2;
					player.hasAppeal = false;
				}
				player.inBathroom = false;
				input.nextLine();
				System.out.println();
			}
			if(player.HP <= 0)
			{
				display("\n"+hayes.name+" defeated you!~");		
				defeated = true;
				continue;
			}

			//End fight with Dr.Hayes, shop, inventory, leveup continue story, reset Stats
			display("Phew, that was a tough one.~");
			display("But luckily you leveled up!~");
			player.levelUp();
			player.setDefaultStats();
			display("Perfect, you\'re well on your way to beating the game! (maybe)~");
			display("If I had known it was Dr.Hayes, I wouldn\'t of stormed in like that!~");
			display("That battle caught us off guard.~");
			displayln("You know what shouldn\'t catch you off guard by now though?~");
			minigames.defeatedHayes(player);
			System.out.print("");
			Items.shop(player);
			Items.useInventory(player,nan);
			display("I don\'t know about you "+player.name+" but I\'m so over the third floor right now.~");
			display("Let\'s take this party up to the fourth floor.~");
			display("**You go up to the fourth floor, but don\'t really know where to go**~");
			promptYesOrNo("Hey "+player.name+" want to go check out the Math lab?: ");
			display("Awesome, maybe we\'ll find something cool (or another battle)~");
			display("**You enter the math lab, and notice a few things.~");
			display("**You walk up to the board.**~");
			display("**It appears a little smudgy, like someone used their hand to erase it**~");
			display("**There\'s a couple markers on the ground near the board**~");
			display("**You walk over to the window and notice a footprint, like someone was climbing on it to write high up**~");
			display("**Finally, you walk back over to the board**~");
			display("**There\'s something written and you\'re trying to make it out**~");
			display("**\"sose?\",\"spise?\", maybe \"spore?\"**~");
			displayln(player.name+"!! Watch out! That says \"spose!!\"~");
			displayln("!!You are challenged by Dr.Farnum!!~");

			//Start farnum fight, reset stats
			if(player instanceof CompMath || player instanceof MathEducation)
			{
				display("Dr.Farnum has high knowledge of your major!~");
				displayln("Your attacks are reduced in power for this battle!~");
				player.setScale(true,0.85);
			}
			player.setScaleDisplay();
			while(player.HP > 0 || player.hasAppeal)
			{
				player.printStats(farnum);
				int attackCode = attacks.initialCommand();
				attackCode = attacks.hasGPA(player,attackCode);
				System.out.println();
				attacks.studentAttack(player,farnum,attackCode);
				input.nextLine();
				input.nextLine();
				System.out.println();
				if(farnum.HP <= 0) 
				{
					System.out.print("\nYou defeated "+farnum.name+"~");
					input.nextLine();
					break;
				}
				farnum.checkBathroom(player);
				attacks.professorAttack(player,farnum);
				if(player.HP <= 0 && player.hasAppeal)
				{
					System.out.print("\n\n"+farnum.name+" defeated you!~");
					input.nextLine();
					System.out.print("But wait! You were given a second chance during appeals!~");
					player.HP = player.maxHP/2;
					player.hasAppeal = false;
				}
				player.inBathroom = false;
				input.nextLine();
				System.out.println();
			}
			if(player.HP <= 0)
			{
				display("\n"+farnum.name+" defeated you!~");		
				defeated = true;
				continue;
			}

			//End battle with Farnum, shop, inventory, continue story, reset Stats
			player.setDefaultStats();
			display("Oh man, that was battle! Great job!~");
			displayln("You know the drill..~");
			minigames.defeatedFarnum(player);
			System.out.print("");
			Items.shop(player);
			Items.useInventory(player,nan);
			display("Ya know what, can we actually go to the Bio lab real quick?~");
			display("While I was watching the battle, I was eating popcorn and I got the butter all over my hands.~");
			display("I want to use some of that high quality soap in the Bio lab!~");
			display("**You walk over to the Bio lab**~");
			display("**Upon opening the door, you feel realy cold air coming from in front of you**~");
			display("**You want into the small room it\'s coming from, and notice the freezer door is open**~");
			displayln("**Not only that, but there\'s someone in it!**~");
			displayln("!!You are challenged by Dr.Coniglio!!~");

			//Start battle with Coniglio
			if(player instanceof BioEducation || player instanceof BioMedicine)
			{
				display("Dr.Congilio has high knowledge of your major!~");
				displayln("Your attacks are reduced in power for this battle!~");
				player.setScale(true,0.85);
			}
			player.setScaleDisplay();
			while(player.HP > 0 || player.hasAppeal)
			{
				player.printStats(coniglio);
				int attackCode = attacks.initialCommand();
				attackCode = attacks.hasGPA(player,attackCode);
				System.out.println();
				attacks.studentAttack(player,coniglio,attackCode);
				input.nextLine();
				input.nextLine();
				System.out.println();
				if(coniglio.HP <= 0) 
				{
					System.out.print("\nYou defeated "+coniglio.name+"~");
					input.nextLine();
					break;
				}
				attacks.professorAttack(player,coniglio);
				if(player.HP <= 0 && player.hasAppeal)
				{
					System.out.print("\n\n"+coniglio.name+" defeated you!~");
					input.nextLine();
					System.out.print("But wait! You were given a second chance during appeals!~");
					player.HP = player.maxHP/2;
					player.hasAppeal = false;
				}
				player.inBathroom = false;
				input.nextLine();
				System.out.println();
			}
			if(player.HP <= 0)
			{
				display("\n"+coniglio.name+" defeated you!~");		
				defeated = true;
				continue;
			}

			//End fight with coniglio, level up, reset stats
			display("Okay, we need to start being more careful during this tour.~");
			display("Or do we? Because you just leveled up!~");
			player.levelUp();
			player.setDefaultStats();
			display("Aaaaaand, exam time!~");
			minigames.defeatedConiglio(player);
			System.out.print("");
			Items.shop(player);
			Items.useInventory(player,nan);
			display("ONWARD!!~");
			display("Just kidding, I really dont have that much energy..~");
			display("Ya know what would be really great right now?~");
			display("Sitting on really uncomfortable benches that resemble sound waves.~");
			display("**You take a seat on one of the benches**~");
			display("**You try shifting to left a little bit**~");
			display("**You try shifting the right**~");
			display("**You try shif..**~");
			display(player.name+" just stop. That\'s as comfortable as it\'s going to get.~");
			display("**You look over to a room that has a sign that says \"The Cave\"**~");
			display("Well I can definitely tell you there\'s nowhere to sit in there~");
			display("Actually it\'s pretty off limits, we should definitely NOT go in.~");
			display("**You are just STARING at this door**~");
			display("I\'m serious "+player.name+" we can\'t go in there~");
			display("**You are literally staring into this doors soul!**~");
			display("Okay okay, we\'ll go in~");
			display("Might not be a bad idea actually~");
			display("(If he\'s in there, maybe he can help me fix some of the bugs in this game!)~");
			display("After you "+player.name+"~");
			display("**You walk into the room, and it\'s very dark**~");
			display("**All of a sudden your in a field!**~");
			display("**There\'s humanoid figures walking towards you in a zombie like fashion**~");
			displayln("**But wait, one of them looks too real...**~");
			displayln("!!You are challenged by Dr.Joiner!!~");

			//Begin battle with joiner
			if(player instanceof CompMath || player instanceof Engineering)
			{
				display("Dr.Joiner has high knowledge of your major!~");
				displayln("Your attacks are reduced in power for this battle!~");
				player.setScale(true,0.85);
			}
			player.setScaleDisplay();
			while(player.HP > 0 || player.hasAppeal)
			{
				player.printStats(joiner);
				int attackCode = attacks.initialCommand();
				attackCode = attacks.hasGPA(player,attackCode);
				System.out.println();
				attacks.studentAttack(player,joiner,attackCode);
				input.nextLine();
				input.nextLine();
				System.out.println();
				if(joiner.HP <= 0) 
				{
					System.out.print("\nYou defeated "+joiner.name+"~");
					input.nextLine();
					break;
				}
				attacks.professorAttack(player,joiner);
				if(player.HP <= 0 && player.hasAppeal)
				{
					System.out.print("\n\n"+joiner.name+" defeated you!~");
					input.nextLine();
					System.out.print("But wait! You were given a second chance during appeals!~");
					player.HP = player.maxHP/2;
					player.hasAppeal = false;
				}
				player.inBathroom = false;
				input.nextLine();
				System.out.println();
			}
			if(player.HP <= 0)
			{
				display("\n"+joiner.name+" defeated you!~");		
				defeated = true;
				continue;
			}

			//End battle with joiner, set defaults, continue story
			player.setDefaultStats();
			display("I told you not to go inside!~");
			display("But no you had to stare at the door like a weirdo until I said fine.~");
			display("Couldn\'t you say something unique and original?!?1 (oh right...)~");
			display("Anyway..this is weird. There\'s actually no exam.~");
			displayln("Just kidding!~");
			minigames.defeatedJoiner(player);
			System.out.print("");
			Items.shop(player);
			Items.useInventory(player,nan);
			display("END");
		}
	}
}
			
