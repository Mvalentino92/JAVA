public class misc
{
	public static int chooseMajor()
	{
		System.out.println("[1] Math Education: All around major. Pretty even stats. Special attack is called \"Caluclus\"\n"
				+"[2] Bio Education: Higher damage attacks at the cost of more GP consumption. Special attack is called \"Apoptosis\"\n"
				+"[3] Chem Education: Able to heal while also doing damage. Special attack is called \"Dipole Moment\"\n"
				+"[4] Bio Technology: Lower HP at the expensive of stronger basic attacks. Special is called \"Pharmaceutical Frenzy\"\n"
				+"[5] Comp Math: Lower attack at the cost of less GP consumption. Special is called \"Runge Kutta\"\n"
				+"[6] Engineering: Has healing ability, but lower HP. Special is called \"Lone Wolf\"\n"
				+"[7] Bio Medicine: Low attack at the expensive of high HP and healing. Special is called \"Medical Emergency\"");
		System.out.print("Please choose your major. Choose wisely! There\'s no chaning here!: ");
		int majorChoice = 0;
		boolean choseCorrectly = false;
		while(!choseCorrectly)
		{
			while(StemGame.input.hasNextInt())
			{
				majorChoice = StemGame.input.nextInt();
				if(majorChoice >= 0 && majorChoice <= 7)
				{
					choseCorrectly = true;
					break;
				}
				else System.out.print("Please enter an integer within the bounds of your choices: ");
			}
			if(choseCorrectly) continue;
			else
			{
				System.out.print("Please enter an integer: ");
				StemGame.input.next();
			}
		}
		if(majorChoice == 0)
		{
			StemGame.display("\nYou are attempting to play as the secret character Evan Wilson.~");
			StemGame.input.nextLine();
			StemGame.display("In order to do so, you must enter the secret message that unlocks him.~");
			System.out.print("What is Evan Wilson\'s most famous expression that he says?: ");
			String secretMessage = StemGame.input.nextLine();
			secretMessage = secretMessage.toLowerCase();
			//Listing the acceptable answers
			String[] acceptableAnswers = {"how we doing?","how we doing.","how we doing","how we "
				+"doin?","how we doin.","how we doin","how are we doing?","how are we doing.","how are "
					+"we doing","how are we doin?","how are we doin.","how are we doin"};
			for(int i = 0; i < acceptableAnswers.length; i++)
			{
				if(secretMessage.equals(acceptableAnswers[i]))
				{
					StemGame.display("Correct! Evan Wilson unlocked!~");
					return majorChoice;
				}
			}
			StemGame.display("I\'m sorry that is not correct. Returning to major selection.~");
			System.out.println();
			return chooseMajor();
		}
		else
		{
			StemGame.display("Good choice!~");
			StemGame.input.nextLine();
			return majorChoice;
		}
	}
}
