public  class Professor
{
	String name;
	double HP = 100;
	double maxHP;
	boolean charged = false;
	boolean Male = true;

	String atk1,atk2,atk3,atk4,atk5;
	double dam1,dam2,dam3,dam4;


	public Professor(){}

	public void attackOne(Student stud){}
	public void attackTwo(Student stud){}
	public void attackThree(Student stud){}
	public void charge(Student stud){}
	public void finalAttack(Student stud,String name,Professor prof){}

}
//*********************************************************************************************************************************************************************
class Farnum extends Professor
{
	double petPeeve = 1;
	public Farnum()
	{
		name = "Dr.Farnum";
		maxHP = 85;
		HP = maxHP;	

		atk1 = "Euler\'s Relation";
		atk2 = "FFT";
		atk3 = "Sink!";
		atk4 = "ANNIHILATION!!";
		
		dam1 = 10;
		dam2 = 14;
		dam3 = 20;
		dam4 = 37;
	}

	public void attackOne(Student stud)
	{
		double damage = dam1*petPeeve;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk1,damage); 
		stud.HP -= damage;
	}

	public void attackTwo(Student stud)
	{
		double damage = dam2*petPeeve;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk2,damage); 
		stud.HP -= damage;
	}

	public void attackThree(Student stud)
	{
		double damage = dam3*petPeeve;
		if(Math.random() < 1.0/4) System.out.printf("Oh no the attack %s missed!!~",atk3);
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk3,damage); 
			stud.HP -= damage;
		}
	}

	public void charge(Student stud)
	{
		String gender = null;
		if(Male) gender = "his";
		else gender = "her";
		System.out.printf("%s is charging %s special attack!!!!~",name,gender);
		charged = true;
	}

	public void finalAttack(Student stud,String name, Professor prof)
	{
		double damage = dam4*petPeeve;
		System.out.printf("Fixed Points? Health Points? You\'ll have none of either left!\n"
				+"%s used %s!! inflicting a MASSIVE %.2f damage!!~",name,atk4,damage);
		stud.HP -= damage;
	}

	public void checkBathroom(Student stud)
	{
		if(stud.inBathroom)
		{
			System.out.print(name+" attack increased!!~");
			StemGame.input.nextLine();
			petPeeve += 0.2;
		}
	}
}
//*********************************************************************************************************************************************************************
class Joiner extends Professor
{
	public Joiner()
	{
		name = "Dr.Joiner";
		maxHP = 100;
		HP = maxHP;	

		atk1 = "Compile";
		atk2 = "Gravity!";
		atk3 = "Digitize";
		atk4 = "Blackhole";
		
		dam1 = 12;
		dam2 = 15;
		dam3 = 22;
		dam4 = 35;
	}

	public void attackOne(Student stud)
	{
		double damage = dam1;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk1,damage); 
		stud.HP -= damage;
	}

	public void attackTwo(Student stud)
	{
		double damage = dam2;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk2,damage); 
		stud.HP -= damage;
	}

	public void attackThree(Student stud)
	{
		double damage = dam3;
		if(Math.random() < 1.0/4) System.out.printf("Oh no the attack %s missed!!~",atk3);
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk3,damage); 
			stud.HP -= damage;
		}
	}

	public void charge(Student stud)
	{
		String gender = null;
		if(Male) gender = "his";
		else gender = "her";
		System.out.printf("%s is charging %s special attack!!!!~",name,gender);
		charged = true;
	}

	public void finalAttack(Student stud,String name, Professor prof)
	{
		double damage = dam4;
		System.out.printf("You cant escape the impending doom!\n"
				+"%s used %s!! inflicting a MASSIVE %.2f damage!!~",name,atk4,damage);
		stud.HP -= damage;
	}
}
//*********************************************************************************************************************************************************************
class Hayes extends Professor
{
	public Hayes()
	{
		name = "Dr.Hayes";
		maxHP = 100;
		HP = maxHP;	

		atk1 = "Helicobacter Pylori";
		atk2 = "Colonization!";
		atk3 = "Reverse Compliment";
		atk4 = "Jack-of-all-trades";
		
		dam1 = 12;
		dam2 = 15;
		dam3 = 19;
		dam4 = 40;
	}

	public void attackOne(Student stud)
	{
		double damage = dam1;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk1,damage); 
		stud.HP -= damage;
	}

	public void attackTwo(Student stud)
	{
		double damage = dam2;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk2,damage); 
		stud.HP -= damage;
	}

	public void attackThree(Student stud)
	{
		double damage = dam3;
		if(Math.random() < 1.0/4) System.out.printf("Oh no the attack %s missed!!~",atk3);
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk3,damage); 
			stud.HP -= damage;
		}
	}

	public void charge(Student stud)
	{
		String gender = null;
		if(Male) gender = "his";
		else gender = "her";
		System.out.printf("%s is charging %s special attack!!!!~",name,gender);
		charged = true;
	}

	public void finalAttack(Student stud,String name, Professor prof)
	{
		//if else statments that create a new instance of whatever professor class and instantly calls the .finalAttack(method)
		double damage = dam4;
		System.out.printf("A lot a bit of this, a lot of bit of that\n%s used %s!~\n\n",name,atk4);
		StemGame.input.nextLine();
		double rando = (int)(Math.random()*8) + 1;
		if(rando == 1) (new Farnum()).finalAttack(stud,name,prof);
		else if(rando == 2) (new Joiner()).finalAttack(stud,name,prof);
		else if(rando == 3) (new Coniglio()).finalAttack(stud,name,prof);
		else if(rando == 4) (new Merrit()).finalAttack(stud,name,prof);
		else if(rando == 5) (new Nan()).finalAttack(stud,name,prof);
		else if(rando == 6) (new Baldwin()).finalAttack(stud,name,prof);
		else if(rando == 7) (new R()).finalAttack(stud,name,prof);
		else if(rando == 8) (new Cuesta()).finalAttack(stud,name,prof);
	}
}
//*********************************************************************************************************************************************************************
class Coniglio extends Professor
{
	public Coniglio()
	{
		name = "Dr.Coniglio";
		maxHP = 130;
		HP = maxHP;	

		atk1 = "T-Cells";
		atk2 = "Telophase";
		atk3 = "Mutate";
		atk4 = "Metastasize";
		
		dam1 = 15;
		dam2 = 20;
		dam3 = 25;
		dam4 = 40;
	}

	public void attackOne(Student stud)
	{
		double damage = dam1;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk1,damage); 
		stud.HP -= damage;
	}

	public void attackTwo(Student stud)
	{
		double damage = dam2;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk2,damage); 
		stud.HP -= damage;
	}

	public void attackThree(Student stud)
	{
		double damage = dam3;
		if(Math.random() < 1.0/4) System.out.printf("Oh no the attack %s missed!!~",atk3);
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk3,damage); 
			stud.HP -= damage;
		}
	}

	public void charge(Student stud)
	{
		String gender = null;
		if(Male) gender = "his";
		else gender = "her";
		System.out.printf("%s is charging %s special attack!!!!~",name,gender);
		charged = true;
	}

	public void finalAttack(Student stud,String name, Professor prof)
	{
		double damage = dam4;
		System.out.printf("Theres no stopping this attack now!\n"
				+"%s used %s!! inflicting a MASSIVE %.2f damage!!~",name,atk4,damage);
		stud.HP -= damage;
	}
}
//*********************************************************************************************************************************************************************
class R extends Professor
{
	double practiceScale = 1;
	public R()
	{
		name = "Dr.R";
		maxHP = 130;
		HP = maxHP;	
		Male = false;

		atk1 = "Practice Makes Perfect";
		atk2 = "Combustion";
		atk3 = "Electronegativity";
		atk4 = "Chemistry is Life";
		
		dam1 = 12;
		dam2 = 16;
		dam3 = 22;
		dam4 = 30;
	}

	public void attackOne(Student stud)
	{
		double damage = dam1*practiceScale;
		practiceScale += 0.2;
		System.out.printf("%s used %s inflicting %.2f damage!!, and increased this moves power!~",name,atk1,damage); 
		stud.HP -= damage;
	}

	public void attackTwo(Student stud)
	{
		double damage = dam2;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk2,damage); 
		stud.HP -= damage;
	}

	public void attackThree(Student stud)
	{
		double damage = dam3;
		if(Math.random() < 1.0/4) System.out.printf("Oh no the attack %s missed!!~",atk3);
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk3,damage); 
			stud.HP -= damage;
		}
	}

	public void charge(Student stud)
	{
		String gender = null;
		if(Male) gender = "his";
		else gender = "her";
		System.out.printf("%s is charging %s special attack!!!!~",name,gender);
		charged = true;
	}

	public void finalAttack(Student stud,String name, Professor prof)
	{
		double damage = dam4;
		System.out.printf("It\'s everywhere you can\'t escape it!\n"
				+"%s used %s!! stealing %.2f HP!!!~",name,atk4,damage);
		stud.HP -= damage;
		if(HP + damage > maxHP) HP = maxHP;
		else HP += damage;
	}
}
//*********************************************************************************************************************************************************************
class Merrit extends Professor
{
	public Merrit()
	{
		name = "Dr.Merrit";
		maxHP = 145;
		HP = maxHP;	

		atk1 = "Carbon";
		atk2 = "Catalyst";
		atk3 = "Hydrolosis";
		atk4 = "Half-Life";
		
		dam1 = 18;
		dam2 = 25;
		dam3 = 30;
		dam4 = 40;
	}

	public void attackOne(Student stud)
	{
		double damage = dam1;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk1,damage); 
		stud.HP -= damage;
	}

	public void attackTwo(Student stud)
	{
		double damage = dam2;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk2,damage); 
		stud.HP -= damage;
	}

	public void attackThree(Student stud)
	{
		double damage = dam3;
		if(Math.random() < 1.0/4) System.out.printf("Oh no the attack %s missed!!~",atk3);
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk3,damage); 
			stud.HP -= damage;
		}
	}

	public void charge(Student stud)
	{
		String gender = null;
		if(Male) gender = "his";
		else gender = "her";
		System.out.printf("%s is charging %s special attack!!!!~",name,gender);
		charged = true;
	}

	public void finalAttack(Student stud,String name, Professor prof)
	{
		double damage = dam4;
		System.out.println("I'd rather take all your life, but I\'ll take it!");
		if(Math.abs(maxHP/2 - HP) < (maxHP/10))
		{
			System.out.printf("%s used %s doing double damage and inflicting a MASSIVE %d damage!!~",name,atk4,(damage*2));
			stud.HP -= damage*2;
		}
		else
		{
			System.out.printf("%s used %s inflicting %d damage!!~",name,atk4,damage);
			stud.HP -= damage;
		}
	}
}
//*********************************************************************************************************************************************************************
class Nan extends Professor
{
	public Nan()
	{
		name = "Nan";
		maxHP = 160;
		HP = maxHP;	
		Male = false;

		atk1 = "Phylogeny";
		atk2 = "Dissect";
		atk3 = "Acid Spill";
		atk4 = "Natural Adaptation";
		
		dam1 = 12;
		dam2 = 18;
		dam3 = 24;
		dam4 = 40;
	}

	public void attackOne(Student stud)
	{
		double damage = dam1;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk1,damage); 
		stud.HP -= damage;
	}

	public void attackTwo(Student stud)
	{
		double damage = dam2;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk2,damage); 
		stud.HP -= damage;
	}

	public void attackThree(Student stud)
	{
		double damage = dam3;
		if(Math.random() < 1.0/4) System.out.printf("Oh no the attack %s missed!!~",atk3);
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk3,damage); 
			stud.HP -= damage;
		}
	}

	public void charge(Student stud)
	{
		String gender = null;
		if(Male) gender = "his";
		else gender = "her";
		System.out.printf("%s is charging %s special attack!!!!~",name,gender);
		charged = true;
	}

	public void finalAttack(Student stud,String name, Professor prof)
	{
		double damage = dam4;
		System.out.printf("Life has it\'s ways.\n"
				+"%s used %s!! Increased power to all attacks!~",name,atk4,damage);
		prof.dam1 += 7;
		prof.dam2 += 7;
		prof.dam3 += 7;
	}
}
//*********************************************************************************************************************************************************************
class Cuesta extends Professor
{
	public Cuesta()
	{
		name = "Prof.Cuesta";
		maxHP = 150;
		HP = maxHP;	

		atk1 = "Hypochloric Acid";
		atk2 = "Halogens";
		atk3 = "Force";
		atk4 = "Nova";
		
		dam1 = 10;
		dam2 = 14;
		dam3 = 20;
		dam4 = 25;
	}

	public void attackOne(Student stud)
	{
		double damage = dam1;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk1,damage); 
		stud.HP -= damage;
	}

	public void attackTwo(Student stud)
	{
		double damage = dam2;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk2,damage); 
		stud.HP -= damage;
	}

	public void attackThree(Student stud)
	{
		double damage = dam3;
		if(Math.random() < 1.0/4) System.out.printf("Oh no the attack %s missed!!~",atk3);
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk3,damage); 
			stud.HP -= damage;
		}
	}

	public void charge(Student stud)
	{
		String gender = null;
		if(Male) gender = "his";
		else gender = "her";
		System.out.printf("%s is charging %s special attack!!!!~",name,gender);
		charged = true;
	}

	public void finalAttack(Student stud,String name, Professor prof)
	{
		double damage = dam4;
		System.out.printf("The universe knows no bounds\n"
				+"%s used %s!! inflicting a MASSIVE %.2f damage!!~",name,atk4,damage);
		stud.HP -= damage;
	}

	public void getPHD()
	{
		name = "Dr.Cuesta";
		maxHP += 50;
		HP = maxHP;

		atk1 = "Perchloric Acid";
		atk2 = "Noble Gases";
		atk3 = "Net Force";
		atk4 = "SUPER NOVA!!";
		
		dam1 += 5;
		dam2 += 7;
		dam3 += 9;
		dam4 += 15;
	}
}
//*********************************************************************************************************************************************************************
class Baldwin extends Professor
{
	public Baldwin()
	{
		name = "Baldwin";
		maxHP = 160;
		HP = maxHP;	

		atk1 = "Evaluation";
		atk2 = "Lesson Plan";
		atk3 = "STEM Education";
		atk4 = "Sapientia et Doctrina";
		
		dam1 = 12;
		dam2 = 18;
		dam3 = 24;
		dam4 = 38;
	}

	public void attackOne(Student stud)
	{
		double damage = dam1;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk1,damage); 
		stud.HP -= damage;
	}

	public void attackTwo(Student stud)
	{
		double damage = dam2;
		System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk2,damage); 
		stud.HP -= damage;
	}

	public void attackThree(Student stud)
	{
		double damage = dam3;
		if(Math.random() < 1.0/4) System.out.printf("Oh no the attack %s missed!!~",atk3);
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!~",name,atk3,damage); 
			stud.HP -= damage;
		}
	}

	public void charge(Student stud)
	{
		String gender = null;
		if(Male) gender = "his";
		else gender = "her";
		System.out.printf("%s is charging %s special attack!!!!~",name,gender);
		charged = true;
	}

	public void finalAttack(Student stud,String name, Professor prof)
	{
		double damage = dam4;
		System.out.printf("Wisdom and learning.\n"
				+"%s used %s!! Damaging %s for %d damage, and also draining all GP!~",name,atk4,stud.name,damage);
		stud.HP -= dam4;
		stud.GP = 0.0;
	}
}
