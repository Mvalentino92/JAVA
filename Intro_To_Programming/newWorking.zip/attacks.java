public class attacks
{
	public static int hasGPA(Student stud, int attackCode)
	{
		try
		{
			String message = "You dont have the GPA for that! Choose another move: ";
			switch(attackCode)
			{
				case 1: 
				if(stud.GP >= stud.GPCost1) return attackCode;
				else
				{
					System.out.print(message);
					return hasGPA(stud,StemGame.input.nextInt());
				}

				case 2: 
				if(stud.GP >= stud.GPCost2) return attackCode;
				else
				{
					System.out.print(message);
					return hasGPA(stud,StemGame.input.nextInt());
				}

				case 3: 
				if(stud.GP >= stud.GPCost3) return attackCode;
				else
				{
					System.out.print(message);
					return hasGPA(stud,StemGame.input.nextInt());
				}

				case 4: 
				if(stud.GP >= stud.GPCost4) return attackCode;
				else
				{
					System.out.print(message);
					return hasGPA(stud,StemGame.input.nextInt());
				}

				case 5:
				if(stud.GP >= stud.GPCost5) return attackCode;
				else
				{
					System.out.print(message);
					return hasGPA(stud,StemGame.input.nextInt());
				}

				case 6:
				if(stud.GP >= stud.GPCost6) return attackCode;
				else
				{
					System.out.print("You're GPA is too low! You cant afford to miss a minute of class! Choose something else: ");
					return hasGPA(stud,StemGame.input.nextInt());
				}

				case 7:
				if(stud.GP < 4.0) return attackCode;
				else
				{
					System.out.print("You already have a 4.0! Choose something else: ");
					return hasGPA(stud,StemGame.input.nextInt());
				}

				case 8:
				if(stud.items.isEmpty())
				{
					System.out.print("You have no items! Choose something else: ");
					return hasGPA(stud,StemGame.input.nextInt());
				}
				for(int i = 0; i < stud.items.size(); i++)
				{
					System.out.printf("[%d] %s: %s\n",i,stud.items.get(i).name,stud.items.get(i).description);
				}
				System.out.print("Choose your item: ");
				while(!StemGame.input.hasNextInt())
				{
					System.out.print("Please enter an integer: ");
					StemGame.input.next();
				}
				int choice = StemGame.input.nextInt();
				if(choice < 0 || choice >= stud.items.size())
				{
					return hasGPA(stud,8);
				}
				else
				{
					stud.itemChoice = choice;
				       	return 8;
				}

				default:
				System.out.print("Please enter a number within the bounds of your commands!: ");
				return hasGPA(stud,StemGame.input.nextInt());
			}
		}
		catch(Exception e)
		{
			do
			{
				System.out.print("Please enter an interger: ");
				StemGame.input.next();
			} while(!StemGame.input.hasNextInt());
			return hasGPA(stud,StemGame.input.nextInt());
		}
	}

	public static int initialCommand()
	{
		System.out.print("Choose your command: ");
		while(!StemGame.input.hasNextInt())
		{
			System.out.print("Please enter an integer: ");
			StemGame.input.next();
		}
		return StemGame.input.nextInt();
	}

	public static void studentAttack(Student stud, Professor prof, int attackCode)
	{
		if(attackCode == 1) stud.attackOne(prof);
		else if(attackCode == 2) stud.attackTwo(prof);
		else if(attackCode == 3) stud.attackThree(prof);
		else if(attackCode == 4) stud.attackFour(prof);
		else if(attackCode == 5) stud.attackFive(prof);
		else if(attackCode == 6) stud.goToBathroom();
		else if(attackCode == 7) stud.study();
		else if(attackCode == 8) 
		{
			stud.items.get(stud.itemChoice).useItem(stud,prof);
			stud.items.remove(stud.itemChoice);
		}
	}

	public static void professorAttack(Student stud, Professor prof)
	{
		if(prof.charged)
		{
			if(stud.inBathroom && prof.name != "Nan") 
			{
				System.out.print("The attack missed!!~");
				prof.charged = false;
			}
			else
			{
				prof.finalAttack(stud,prof.name,prof);
				prof.charged = false;
			}
		}
		else
		{
			double randomAttack = Math.random();
			if(stud.inBathroom) 
			{
				if(randomAttack <= 0.15) prof.charge(stud);
				else System.out.print("The attack missed!!~");
			}
			else
			{
				if(randomAttack <= 0.15) prof.charge(stud);
				else if(randomAttack > 0.15 && randomAttack <= 0.35) prof.attackThree(stud);
				else if(randomAttack > 0.35 && randomAttack <= 0.65) prof.attackTwo(stud);
				else prof.attackOne(stud);
			}
		}
	}
}
