import java.util.*;
public class Student
{
	//Basic attributes every subclass will have
	String name;
	double HP = 100.0;
	double maxHP;
	double damageScale;

	double cougarDollars = 1;
	ArrayList<Items> items = new ArrayList<>();
	int itemCap = 3;
	int itemChoice = 0;

	double GP = 4.0;
	boolean inBathroom = false;
	String attackList = null;

	String atk1,atk2,atk3,atk4,atk5;
	double dam1,dam2,dam3,dam4,dam5;
	double defaultGPCost1,defaultGPCost2,defaultGPCost3,defaultGPCost4,defaultGPCost5,defaultGPCost6;
	double GPCost1,GPCost2,GPCost3,GPCost4,GPCost5,GPCost6;

	//Basic instantiation of class
	public Student(String name)
	{
		this.name = name;
	}

	//The study method. Will increase GPA
	public void study()
	{
		if(GP > 2.5 && GP < 4.0)
		{
			System.out.print("Your GP capped at 4.0!");
			GP = 4.0;
		}
		else
		{
			GP += 1.5;
			System.out.print("You gained 1.5 GPA! Good job!");
		}
	}

	//The goToBathroom method. Will set to true, and act as defending for that round
	public void goToBathroom()
	{
		inBathroom = true;
		GP -= GPCost6;
		System.out.print("You just lost "+GPCost6+" GP! Stay in class!");
	}

	public void printStats(Professor prof)
	{
		System.out.print(attackList);
		System.out.print("[8] Items: ");
		for(int i = 0; i < items.size(); i++)
		{
			System.out.printf("[%s: %s] ",items.get(i).name,items.get(i).description);
		}
		System.out.println("\nPlayer HP: "+HP+" - Player GP: "+GP+" - Professor HP: "+prof.HP);
	}

	public void attackOne(Professor prof){}
	public void attackTwo(Professor prof){}
	public void attackThree(Professor prof){}
	public void attackFour(Professor prof){}
	public void attackFive(Professor prof){}

}
//*********************************************************************************************************************************************************************
class CompMath extends Student
{
	public CompMath(String name)
	{
		super(name);
		maxHP = 105;
		HP = maxHP;
		damageScale = 1;
		items.add(new Pretzel());
		items.add(new RedBull());

		atk1 = "Number Crunch";
		atk2 = "FOIL";
		atk3 = "Euler\'s Method";
		atk4 = "Midpoint Method";
		atk5 = "Runge Kutta!";

		dam1 = 8;
		dam2 = 12;
		dam3 = 15;
		dam4 = 21;
		dam5 = 30;

		defaultGPCost1 = 0;
		defaultGPCost2 = 0;
		defaultGPCost3 = 1;
		defaultGPCost4 = 2;
		defaultGPCost5 = 3.5;
		defaultGPCost6 = 1;

		GPCost1 = defaultGPCost1;
		GPCost2 = defaultGPCost2;
		GPCost3 = defaultGPCost3;
		GPCost4 = defaultGPCost4;
		GPCost5 = defaultGPCost5;
		GPCost6 = defaultGPCost6;

		attackList = "[1] "+atk1+": Deals "+dam1+" damage.\n"
		+"[2] "+atk2+": Deals "+dam2+" damage. 1/5 chance to miss.\n"
		+"[3] "+atk3+": Deals "+dam3+" damage. Costs "+GPCost3+" GP.\n"
		+"[4] "+atk4+": Deals "+dam4+" damage. Costs "+GPCost4+" GP.\n"
		+"[5] "+atk5+": Deals "+dam5+" damage. Costs "+GPCost5+" GP.\n"
		+"[6] Go to Bathroom: Takes no damage the next turn, but lose "+GPCost6+" GP.\n"
		+"[7] Study!: Hit the books!! Gain 1.5 GP.\n";
	}

	public void attackOne(Professor prof)
	{
		double damage = dam1*damageScale;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk1,damage);
		prof.HP -= damage;
	}
	
	public void attackTwo(Professor prof)
	{
		double damage = dam2*damageScale;
		if(Math.random() < 1.0/5) 
		{
			System.out.print("Oh! The attack missed!");
		}
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!",name,atk2,damage);
			prof.HP -= damage;
		}
	}

	public void attackThree(Professor prof)
	{
		double damage = dam3*damageScale;
		GP -= GPCost3;;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk3,damage);
		prof.HP -= damage;
	}

	public void attackFour(Professor prof)
	{
		double damage = dam4*damageScale;
		GP -= GPCost4;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk4,damage);
		prof.HP -= damage;
	}

	public void attackFive(Professor prof)
	{
		double damage = dam5*damageScale;
		GP -= GPCost5;
		System.out.printf("Feel the wrath of higher order methods!\n%s used %s inflicting %.2f damage!!",name,atk5,damage);
		prof.HP -= damage;
	}
}
//*********************************************************************************************************************************************************************
class BioTechnology extends Student
{
	public BioTechnology(String name)
	{
		super(name);
		maxHP = 90;
		HP = maxHP;
		damageScale = 1;
		items.add(new Pretzel());
		items.add(new RedBull());
		
		atk1 = "PCR";
		atk2 = "Centrifuge";
		atk3 = "Chemical Burn";
		atk4 = "Ethidium Bromide";
		atk5 = "Pharmaceutical Frenzy!";

		dam1 = 9;
		dam2 = 14;
		dam3 = 17;
		dam4 = 23;
		dam5 = 35;

		defaultGPCost1 = 0;
		defaultGPCost2 = 0;
		defaultGPCost3 = 1;
		defaultGPCost4 = 2.5;
		defaultGPCost5 = 4.0;
		defaultGPCost6 = 1;

		GPCost1 = defaultGPCost1;
		GPCost2 = defaultGPCost2;
		GPCost3 = defaultGPCost3;
		GPCost4 = defaultGPCost4;
		GPCost5 = defaultGPCost5;
		GPCost6 = defaultGPCost6;

		attackList = "[1] "+atk1+": Deals "+dam1+" damage.\n"
		+"[2] "+atk2+": Deals "+dam2+" damage. 1/4 chance to miss.\n"
		+"[3] "+atk3+": Deals "+dam3+" damage. Costs "+GPCost3+" GP.\n"
		+"[4] "+atk4+": Deals "+dam4+" damage. Costs "+GPCost4+" GP.\n"
		+"[5] "+atk5+": Deals "+dam5+" damage. Costs "+GPCost5+" GP.\n"
		+"[6] Go to Bathroom: Takes no damage the next turn, but lose "+GPCost6+" GP.\n"
		+"[7] Study!: Hit the books!! Gain 1.5 GP.\n";
	}

	public void attackOne(Professor prof)
	{
		double damage = dam1*damageScale;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk1,damage);
		prof.HP -= damage;
	}
	
	public void attackTwo(Professor prof)
	{
		double damage = dam2*damageScale;
		if(Math.random() < 1.0/4) 
		{
			System.out.print("Oh! The attack missed!");
		}
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!",name,atk2,damage);
			prof.HP -= damage;
		}
	}

	public void attackThree(Professor prof)
	{
		double damage = dam3*damageScale;
		GP -= GPCost3;;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk3,damage);
		prof.HP -= damage;
	}

	public void attackFour(Professor prof)
	{
		double damage = dam4*damageScale;
		GP -= GPCost4;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk4,damage);
		prof.HP -= damage;
	}

	public void attackFive(Professor prof)
	{
		double damage = dam5*damageScale;
		GP -= GPCost5;
		System.out.printf("Side Effects: May cause defeat!\n%s used %s inflicting %.2f damage!!",name,atk5,damage);
		prof.HP -= damage;
	}
}
//*********************************************************************************************************************************************************************
class BioMedicine extends Student
{
	public BioMedicine(String name)
	{
		super(name);
		maxHP = 115;
		HP = maxHP;
		damageScale = 1;
		items.add(new Pretzel());
		items.add(new RedBull());
		
		atk1 = "Pressure Point";
		atk2 = "Wrong Diagnosis";
		atk3 = "Defibrillator";
		atk4 = "Anemia";
		atk5 = "Medical Emergency";

		dam1 = 7;
		dam2 = 10;
		dam3 = 14;
		dam4 = 20;
		dam5 = 40;

		defaultGPCost1 = 0;
		defaultGPCost2 = 0;
		defaultGPCost3 = 1;
		defaultGPCost4 = 1.5;
		defaultGPCost5 = 3.5;
		defaultGPCost6 = 1;

		GPCost1 = defaultGPCost1;
		GPCost2 = defaultGPCost2;
		GPCost3 = defaultGPCost3;
		GPCost4 = defaultGPCost4;
		GPCost5 = defaultGPCost5;
		GPCost6 = defaultGPCost6;

		attackList = "[1] "+atk1+": Deals "+dam1+" damage.\n"
		+"[2] "+atk2+": Deals "+dam2+" damage. 1/5 chance to miss.\n"
		+"[3] "+atk3+": Deals "+dam3+" damage. Costs "+GPCost3+" GP.\n"
		+"[4] "+atk4+": Deals "+dam4+" damage. Costs "+GPCost4+" GP.\n"
		+"[5] "+atk5+": Heals yourself for "+dam5+" damage. Costs "+GPCost5+" GP.\n"
		+"[6] Go to Bathroom: Takes no damage the next turn, but lose "+GPCost6+" GP.\n"
		+"[7] Study!: Hit the books!! Gain 1.5 GP.\n";
	}

	public void attackOne(Professor prof)
	{
		double damage = dam1*damageScale;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk1,damage);
		prof.HP -= damage;
	}
	
	public void attackTwo(Professor prof)
	{
		double damage = dam2*damageScale;
		if(Math.random() < 1.0/5) 
		{
			System.out.print("Oh! The attack missed!");
		}
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!",name,atk2,damage);
			prof.HP -= damage;
		}
	}

	public void attackThree(Professor prof)
	{
		double damage = dam3*damageScale;
		GP -= GPCost3;;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk3,damage);
		prof.HP -= damage;
	}

	public void attackFour(Professor prof)
	{
		double damage = dam4*damageScale;
		GP -= GPCost4;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk4,damage);
		prof.HP -= damage;
	}

	public void attackFive(Professor prof)
	{
		double damage = dam5*damageScale;
		GP -= GPCost5;
		System.out.printf("Looks like Med School finally payed off!\n%s used %s healing for %.2f damage!!",name,atk5,damage);
		if(HP + damage >= maxHP) HP = maxHP;
		else HP += damage;
	}
}
//*********************************************************************************************************************************************************************
class MathEducation extends Student
{
	public MathEducation(String name)
	{
		super(name);
		maxHP = 100;
		HP = maxHP;
		damageScale = 1;
		items.add(new Pretzel());
		items.add(new RedBull());
		
		atk1 = "Arithmetic";
		atk2 = "Algebra";
		atk3 = "Trigonometry";
		atk4 = "Pre-Calc";
		atk5 = "Calculus";

		dam1 = 8;
		dam2 = 14;
		dam3 = 18;
		dam4 = 22;
		dam5 = 28;

		defaultGPCost1 = 0;
		defaultGPCost2 = 0;
		defaultGPCost3 = 1.5;
		defaultGPCost4 = 2.0;
		defaultGPCost5 = 3.5;
		defaultGPCost6 = 1;

		GPCost1 = defaultGPCost1;
		GPCost2 = defaultGPCost2;
		GPCost3 = defaultGPCost3;
		GPCost4 = defaultGPCost4;
		GPCost5 = defaultGPCost5;
		GPCost6 = defaultGPCost6;

		attackList = "[1] "+atk1+": Deals "+dam1+" damage.\n"
		+"[2] "+atk2+": Deals "+dam2+" damage. 1/4 chance to miss.\n"
		+"[3] "+atk3+": Deals "+dam3+" damage. Costs "+GPCost3+" GP.\n"
		+"[4] "+atk4+": Deals "+dam4+" damage. Costs "+GPCost4+" GP.\n"
		+"[5] "+atk5+": Deals "+dam5+" damage. Costs "+GPCost5+" GP.\n"
		+"[6] Go to Bathroom: Takes no damage the next turn, but lose "+GPCost6+" GP.\n"
		+"[7] Study!: Hit the books!! Gain 1.5 GP.\n";
	}

	public void attackOne(Professor prof)
	{
		double damage = dam1*damageScale;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk1,damage);
		prof.HP -= damage;
	}
	
	public void attackTwo(Professor prof)
	{
		double damage = dam2*damageScale;
		if(Math.random() < 1.0/4) 
		{
			System.out.print("Oh! The attack missed!");
		}
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!",name,atk2,damage);
			prof.HP -= damage;
		}
	}

	public void attackThree(Professor prof)
	{
		double damage = dam3*damageScale;
		GP -= GPCost3;;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk3,damage);
		prof.HP -= damage;
	}

	public void attackFour(Professor prof)
	{
		double damage = dam4*damageScale;
		GP -= GPCost4;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk4,damage);
		prof.HP -= damage;
	}

	public void attackFive(Professor prof)
	{
		double damage = dam5*damageScale;
		GP -= GPCost5;
		System.out.printf("Bow to the ultimate math!\n%s used %s inflicting %.2f damage!!",name,atk5,damage);
		prof.HP -= damage;
	}
}
//*********************************************************************************************************************************************************************
class BioEducation extends Student
{
	public BioEducation(String name)
	{
		super(name);
		maxHP = 100;
		HP = maxHP;
		damageScale = 1;
		items.add(new Pretzel());
		items.add(new RedBull());
		
		atk1 = "Pseudomonas Aeruginosa";
		atk2 = "Adaptation";
		atk3 = "Lysosome";
		atk4 = "Stratosphere";
		atk5 = "Apoptosis";

		dam1 = 8;
		dam2 = 14;
		dam3 = 18;
		dam4 = 22;
		dam5 = 40;

		defaultGPCost1 = 0;
		defaultGPCost2 = 0;
		defaultGPCost3 = 1.5;
		defaultGPCost4 = 2.0;
		defaultGPCost5 = 3.5;
		defaultGPCost6 = 1;

		GPCost1 = defaultGPCost1;
		GPCost2 = defaultGPCost2;
		GPCost3 = defaultGPCost3;
		GPCost4 = defaultGPCost4;
		GPCost5 = defaultGPCost5;
		GPCost6 = defaultGPCost6;

		attackList = "[1] "+atk1+": Deals "+dam1+" damage.\n"
		+"[2] "+atk2+": Deals "+dam2+" damage. 1/4 chance to miss.\n"
		+"[3] "+atk3+": Deals "+dam3+" damage. Costs "+GPCost3+" GP.\n"
		+"[4] "+atk4+": Deals "+dam4+" damage. Costs "+GPCost4+" GP.\n"
		+"[5] "+atk5+": Deals "+dam5+" damage, and inflicts 25 damage on self. Costs "+GPCost5+" GP.\n"
		+"[6] Go to Bathroom: Takes no damage the next turn, but lose "+GPCost6+" GP.\n"
		+"[7] Study!: Hit the books!! Gain 1.5 GP.\n";
	}

	public void attackOne(Professor prof)
	{
		double damage = dam1*damageScale;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk1,damage);
		prof.HP -= damage;
	}
	
	public void attackTwo(Professor prof)
	{
		double damage = dam2*damageScale;
		if(Math.random() < 1.0/4) 
		{
			System.out.print("Oh! The attack missed!");
		}
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!",name,atk2,damage);
			prof.HP -= damage;
		}
	}

	public void attackThree(Professor prof)
	{
		double damage = dam3*damageScale;
		GP -= GPCost3;;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk3,damage);
		prof.HP -= damage;
	}

	public void attackFour(Professor prof)
	{
		double damage = dam4*damageScale;
		GP -= GPCost4;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk4,damage);
		prof.HP -= damage;
	}

	public void attackFive(Professor prof)
	{
		double damage = dam5*damageScale;
		GP -= GPCost5;
		System.out.printf("Sacrifice!\n%s used %s inflicting %.2f damage!!, while taking 25 damage!",name,atk5,damage);
		prof.HP -= damage;
		HP -= 25;
	}
}
//*********************************************************************************************************************************************************************
class Engineering extends Student
{
	public Engineering(String name)
	{
		super(name);
		maxHP = 95;
		HP = maxHP;
		damageScale = 1;
		items.add(new Pretzel());
		items.add(new RedBull());
		
		atk1 = "MATLAB Crash";
		atk2 = "Electrical Surge";
		atk3 = "Construct";
		atk4 = "Deconstruct";
		atk5 = "Lone Wolf";

		dam1 = 12;
		dam2 = 16;
		dam3 = 21;
		dam4 = 25;
		dam5 = 20;

		defaultGPCost1 = 0;
		defaultGPCost2 = 0;
		defaultGPCost3 = 1.5;
		defaultGPCost4 = 3;
		defaultGPCost5 = 2.0;
		defaultGPCost6 = 1;

		GPCost1 = defaultGPCost1;
		GPCost2 = defaultGPCost2;
		GPCost3 = defaultGPCost3;
		GPCost4 = defaultGPCost4;
		GPCost5 = defaultGPCost5;
		GPCost6 = defaultGPCost6;

		attackList = "[1] "+atk1+": Deals "+dam1+" damage.\n"
		+"[2] "+atk2+": Deals "+dam2+" damage. 1/4 chance to miss.\n"
		+"[3] "+atk3+": Deals "+dam3+" damage. Costs "+GPCost3+" GP.\n"
		+"[4] "+atk4+": Deals "+dam4+" damage. Costs "+GPCost4+" GP.\n"
		+"[5] "+atk5+": Heals for "+dam5+" damage. Costs "+GPCost5+" GP.\n"
		+"[6] Go to Bathroom: Takes no damage the next turn, but lose "+GPCost6+" GP.\n"
		+"[7] Study!: Hit the books!! Gain 1.5 GP.\n";
	}

	public void attackOne(Professor prof)
	{
		double damage = dam1*damageScale;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk1,damage);
		prof.HP -= damage;
	}
	
	public void attackTwo(Professor prof)
	{
		double damage = dam2*damageScale;
		if(Math.random() < 1.0/4) 
		{
			System.out.print("Oh! The attack missed!");
		}
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!",name,atk2,damage);
			prof.HP -= damage;
		}
	}

	public void attackThree(Professor prof)
	{
		double damage = dam3*damageScale;
		GP -= GPCost3;;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk3,damage);
		prof.HP -= damage;
	}

	public void attackFour(Professor prof)
	{
		double damage = dam4*damageScale;
		GP -= GPCost4;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk4,damage);
		prof.HP -= damage;
	}

	public void attackFive(Professor prof)
	{
		double damage = dam5*damageScale;
		GP -= GPCost5;
		System.out.printf("And then there was one.\n%s used %s healing for %.2f damage!!",name,atk5,damage);
		if(HP + damage >= maxHP) HP = maxHP;
		else HP += damage;
	}
}
//*********************************************************************************************************************************************************************
class ChemEducation extends Student
{
	public ChemEducation(String name)
	{
		super(name);
		maxHP = 100;
		HP = maxHP;
		damageScale = 1;
		items.add(new Pretzel());
		items.add(new RedBull());
		items.add(new RedBull());
		
		atk1 = "Single Bond";
		atk2 = "Double Bond";
		atk3 = "Triple Bond";
		atk4 = "Redox Reaction";
		atk5 = "Dipole Moment";

		dam1 = 7;
		dam2 = 13;
		dam3 = 16;
		dam4 = 20;
		dam5 = 25;

		defaultGPCost1 = 0;
		defaultGPCost2 = 0;
		defaultGPCost3 = 1;
		defaultGPCost4 = 2;
		defaultGPCost5 = 3;
		defaultGPCost6 = 1;

		GPCost1 = defaultGPCost1;
		GPCost2 = defaultGPCost2;
		GPCost3 = defaultGPCost3;
		GPCost4 = defaultGPCost4;
		GPCost5 = defaultGPCost5;
		GPCost6 = defaultGPCost6;

		attackList = "[1] "+atk1+": Deals "+dam1+" damage.\n"
		+"[2] "+atk2+": Deals "+dam2+" damage. 1/5 chance to miss.\n"
		+"[3] "+atk3+": Deals "+dam3+" damage. Costs "+GPCost3+" GP.\n"
		+"[4] "+atk4+": Deals "+dam4+" damage. Costs "+GPCost4+" GP.\n"
		+"[5] "+atk5+": Deals "+dam5+" damage and heals for half the damage done. Costs "+GPCost5+" GP.\n"
		+"[6] Go to Bathroom: Takes no damage the next turn, but lose "+GPCost6+" GP.\n"
		+"[7] Study!: Hit the books!! Gain 1.5 GP.\n";
	}

	public void attackOne(Professor prof)
	{
		double damage = dam1*damageScale;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk1,damage);
		prof.HP -= damage;
	}
	
	public void attackTwo(Professor prof)
	{
		double damage = dam2*damageScale;
		if(Math.random() < 1.0/5) 
		{
			System.out.print("Oh! The attack missed!");
		}
		else
		{
			System.out.printf("%s used %s inflicting %.2f damage!!",name,atk2,damage);
			prof.HP -= damage;
		}
	}

	public void attackThree(Professor prof)
	{
		double damage = dam3*damageScale;
		GP -= GPCost3;;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk3,damage);
		prof.HP -= damage;
	}

	public void attackFour(Professor prof)
	{
		double damage = dam4*damageScale;
		GP -= GPCost4;
		System.out.printf("%s used %s inflicting %.2f damage!!",name,atk4,damage);
		prof.HP -= damage;
	}

	public void attackFive(Professor prof)
	{
		double damage = dam5*damageScale;
		double heal = damage/2;
		GP -= GPCost5;
		System.out.printf("Guess whos the postive change and guess whos the negative?\n"
				+"%s used %s inflicting %.2f damage!!, and healing for %.2f damage!",name,atk5,damage,heal);
		prof.HP -= damage;
		if(HP + heal >= maxHP) HP = maxHP;
		else HP += heal;
	}
}
