public class Items
{
	String name;
	int value;
	String description;

	public Items(){}

	public void useItem(Student stud, Professor prof){}
}

class Pretzel extends Items
{
	public Pretzel()
	{
		name = "Pretzel";
		value = 45;
		description = "Heal for "+value+" HP";
	}

	public void useItem(Student stud, Professor prof)
	{
		System.out.print("Auntie Anns for the win!");
		if(stud.HP + value >= stud.maxHP) stud.HP = stud.maxHP;
              	else stud.HP += value;
	}
}
class RedBull extends Items
{
	public RedBull()
	{
		name = "RedBull";
		value = 4;
		description = "Sets your GP to 4.0";
	}

	public void useItem(Student stud, Professor prof)
	{
		System.out.print("Crammed your way to a 4.0!");
		stud.GP = (double)value;
	}
}

class Chips extends Items
{
	public Chips()
	{
		name = "Chips";
		value = 30;
		description = "Heal for "+value+" HP";
	}

	public void useItem(Student stud, Professor prof)
	{
		System.out.print("Replenished by junk food!");
		if(stud.HP + value >= stud.maxHP) stud.HP = stud.maxHP;
              	else stud.HP += value;
	}
}
class Ursinos extends Items
{
	public Ursinos()
	{
		name = "Ursinos";
		value = 85;
		description = "Heal for "+value+" HP";
	}

	public void useItem(Student stud, Professor prof)
	{
		System.out.print("Now that\'s a good meal!");
		if(stud.HP + value >= stud.maxHP) stud.HP = stud.maxHP;
              	else stud.HP += value;
	}
}
class Ringtone extends Items
{
	public Ringtone()
	{
		name = "Ringtone";
		value = 40;
		description = "Damages the Professor for "+value+" damage";
	}

	public void useItem(Student stud, Professor prof)
	{
		System.out.print("Good for the battle, not for the class!");
		prof.HP -= value;
	}
}
