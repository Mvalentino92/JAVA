import java.util.Scanner;
public class game
{
	static Scanner input = new Scanner(System.in);
	public static void main(String[] args)
	{
		ChemEducation player = new ChemEducation("Mike");
		Farnum farnum = new Farnum();
		Joiner joiner = new Joiner();
		Hayes hayes = new Hayes();

		Items.shop(player);
		Items.useInventory(player,farnum);
		/*while(player.HP > 0)
		{
			double peeveScale = 0.2;
			player.printStats(farnum);
			int attackCode = attacks.initialCommand();
			attackCode = attacks.hasGPA(player,attackCode);
			System.out.println();
			attacks.studentAttack(player,farnum,attackCode);
			if(player.inBathroom)
			{
				System.out.print("\n"+farnum.name+" attack power increased!!");
				farnum.petPeeve += peeveScale;
			}
			game.input.nextLine();
			game.input.nextLine();
			System.out.println();
			if(farnum.HP <= 0) 
			{
				System.out.println("You defeated "+farnum.name);
				break;
			}
			attacks.professorAttack(player,farnum);
			player.inBathroom = false;
			game.input.nextLine();
			System.out.println();
		}
		if(player.HP <= 0) System.out.println("Farnum defeated you!");		
		player.HP = player.maxHP;
		player.GP = 4.0;

		while(player.HP > 0)
		{
			player.printStats(joiner);
			int attackCode = attacks.initialCommand();
			attackCode = attacks.hasGPA(player,attackCode);
			System.out.println();
			attacks.studentAttack(player,joiner,attackCode);
			game.input.nextLine();
			game.input.nextLine();
			System.out.println();
			if(joiner.HP <= 0) 
			{
				System.out.println("You defeated "+joiner.name);
				break;
			}
			attacks.professorAttack(player,joiner);
			player.inBathroom = false;
			game.input.nextLine();
			System.out.println();
		}
		if(player.HP <= 0) System.out.println("Joiner defeated you!");		
		player.HP = player.maxHP;
		player.GP = 4.0;*/

		while(player.HP > 0)
		{
			player.printStats(hayes);
			int attackCode = attacks.initialCommand();
			attackCode = attacks.hasGPA(player,attackCode);
			System.out.println();
			attacks.studentAttack(player,hayes,attackCode);
			game.input.nextLine();
			game.input.nextLine();
			System.out.println();
			if(hayes.HP <= 0) 
			{
				System.out.println("You defeated "+hayes.name);
				break;
			}
			attacks.professorAttack(player,hayes);
			player.inBathroom = false;
			game.input.nextLine();
			System.out.println();
		}
	}
}
