import java.util.Scanner;
public class game
{
	static Scanner input = new Scanner(System.in);
	public static void main(String[] args)
	{
		boolean defeated = false;
		boolean victory = false;
		int major = misc.chooseMajor();
		Student player;
		if(major == 1) player = new MathEducation();
		else if(major == 2) player = new BioEducation();
		else if(major == 3) player = new ChemEducation();
		else if(major == 4) player = new BioTechnology();
		else if(major == 5) player = new CompMath();
		else if(major == 6) player = new Engineering();
		else if(major == 7) player = new BioMedicine();
		else if(major == 0) player = new Wilson();
		else player = new Student();

		Farnum farnum = new Farnum();
		Joiner joiner = new Joiner();
		Hayes hayes = new Hayes();

		if(!player.name.equals("Evan Wilson"))
		{
			System.out.print("What is your name?: ");
			game.input.nextLine();
			String playerName = game.input.nextLine();
			player.name = playerName;
		}

		while(!defeated && !victory)
		{
			while(player.HP > 0)
			{
				player.printStats(farnum);
				int attackCode = attacks.initialCommand();
				attackCode = attacks.hasGPA(player,attackCode);
				System.out.println();
				attacks.studentAttack(player,farnum,attackCode);
				game.input.nextLine();
				game.input.nextLine();
				System.out.println();
				if(farnum.HP <= 0) 
				{
					System.out.println("You defeated "+farnum.name+"\n");
					break;
				}
				attacks.professorAttack(player,farnum);
				player.inBathroom = false;
				game.input.nextLine();
				System.out.println();
			}
			if(player.HP <= 0)
			{
				System.out.println("Farnum defeated you!");		
				defeated = true;
				continue;
			}
			Items.shop(player);
			Items.useInventory(player,farnum);
			minigames.defeatedConiglio(player);
			minigames.defeatedFarnum(player);

			while(player.HP > 0)
			{
				player.printStats(joiner);
				int attackCode = attacks.initialCommand();
				attackCode = attacks.hasGPA(player,attackCode);
				System.out.println();
				attacks.studentAttack(player,joiner,attackCode);
				game.input.nextLine();
				game.input.nextLine();
				System.out.println();
				if(joiner.HP <= 0) 
				{
					System.out.println("You defeated "+joiner.name+"\n");
					break;
				}
				attacks.professorAttack(player,joiner);
				player.inBathroom = false;
				game.input.nextLine();
				System.out.println();
			}
			if(player.HP <= 0)
			{
				System.out.println("Joiner defeated you!");		
				defeated = true;
				continue;
			}
			Items.shop(player);
			Items.useInventory(player,farnum);

			while(player.HP > 0)
			{
				player.printStats(hayes);
				int attackCode = attacks.initialCommand();
				attackCode = attacks.hasGPA(player,attackCode);
				System.out.println();
				attacks.studentAttack(player,hayes,attackCode);
				game.input.nextLine();
				game.input.nextLine();
				System.out.println();
				if(hayes.HP <= 0) 
				{
					System.out.println("You defeated "+hayes.name+"\n");
					break;
				}
				attacks.professorAttack(player,hayes);
				player.inBathroom = false;
				game.input.nextLine();
				System.out.println();
			}
			if(player.HP <= 0)
			{
				System.out.println("Hayes defeated you!");		
				defeated = true;
				continue;
			}
			victory = true;
		}
		if(player.HP > 0) System.out.println("You won!");
		else System.out.println("You have been defeated come back next semester");
	}
}
