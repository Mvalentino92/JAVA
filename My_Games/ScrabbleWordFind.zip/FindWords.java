import java.util.*; 
import java.math.*; 
import java.io.*; 

public class FindWords
{
	//Reads the file containing the numbers into a matrix. 
	public static int[][] getMatrix(String fileName, int fileLines) throws Exception
	{
		File inputFile = new File(fileName);
		Scanner input = new Scanner(inputFile);
		int[][] matrix = new int[fileLines][7];

		for(int i = 0; i < fileLines; i++)
		{
			for(int j = 0; j < 7; j++) matrix[i][j] = input.nextInt();
		}

		return matrix;
	}

	//Returns a matrix containing all possible combinations of the letters in number form.
	public static int[][] getLexCombos(String letters) throws Exception
	{
		//Get the array of numbers.
		letters = letters.toUpperCase();
		int[] array = new int[7];
		for(int i = 0; i < 7; i++)
		{
			array[i] = (int)letters.charAt(i);
		}

		//Sort the numbers.
		for(int i = 0; i < 6; i++)
		{
			int min = array[i];
			int minIndex = i;
			for(int j = i+1; j < 7; j++)
			{
				if(array[j] < min) 
				{
					min = array[j];
					minIndex = j;
				}
			}
			int temp = array[i];
			array[i] = min;
			array[minIndex] = temp;
		}

		//Generate all possible combinations of these numbers in lexographic order.
		int[][] matrix = new int[5040][7];
		File lexoInput = new File("lexOrder.txt");
		Scanner input = new Scanner(lexoInput);

		for(int i = 0; i < matrix.length; i++)
		{
			for(int j = 0; j < 7; j++) matrix[i][j] = array[input.nextInt()];
		}
		return matrix;
	}

	//Check if the current word is a match
	public static int isMatch(int[] scrabble, int[] candidate)
	{
		int count = 0;
		for(int i = 0; i < 7; i++)
		{
			if(scrabble[i] == candidate[i]) count++;
			else return count;
		}
		return count;
	}

	//Function that checks if its a duplicate before adding it to arrayList
	public static boolean isUnique(ArrayList<int[]> matches, int[] potential)
	{
		for(int i = 0; i < matches.size(); i++)
		{
			int[] current = matches.get(i);
			int count = 0;
			for(int j = 0; j < current.length; j++)
			{
				if(current[j] == potential[j]) count++;
			}
			if(count == 7) return false;
		}
		return true;
	}


	//Finds the possible words for this letter combination.
	public static void matches(int[][] scrabble, int[][] combos)
	{
		int index = 0;
		int currentDepth = 0;
		ArrayList<int[]> matches = new ArrayList<>();
		for(int i = 0; i < combos.length; i++)
		{
			for(int j = index; j < scrabble.length; j++)
			{
				int depth = isMatch(combos[i],scrabble[j]);
				if(depth == 7)
				{
					if(isUnique(matches,combos[i])) matches.add(combos[i]);
					currentDepth = depth;
					index++;
					break;
				}
				else if(depth > currentDepth) index++;
				currentDepth = depth;
			}
		}

		//Print everything out.
		System.out.println("There are "+matches.size()+" possible word(s). They are:\n");
		for(int i = 0; i < matches.size(); i++)
		{
			int[] current = matches.get(i);
			for(int j = 0; j < current.length; j++) System.out.print((char)current[j]);
			System.out.println("\n");
		}
	}
	
	public static void main(String[] args) throws Exception
	{
		//Get matrix of scrabble words
		int[][] scrabbleWords = getMatrix("seven2numbers.txt", 34167);

		//Get the list of letters, and the matrix with all possible combos in lex order.
		Scanner input = new Scanner(System.in);
		System.out.print("What are the letters you have?: ");
		String myLetters = input.nextLine();
		int[][] myCombos = getLexCombos(myLetters);
		
		//Get matches and print.
		matches(scrabbleWords,myCombos);
	}
}
