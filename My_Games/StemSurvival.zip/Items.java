public class Items
{
	String name;
	int value;
	String description;
	double cost;
	static double[] costList = new double[7];
	static int itemIndex = 0;
	boolean added = false;

	public Items(){}

	public void useItem(Student stud, Professor prof){}

	//Making the static methods to use items after battle
	public static void useInventory(Student stud,Professor prof)
	{
		if(stud.items.isEmpty()) StemGame.display("Sorry, you have no items to use right now.~");
		else
		{
			System.out.print("Would you like to use an item before the next battle? [y/n]: ");
			String choice = StemGame.input.next();
			System.out.print("");;
			while(StemGame.input.hasNextLine() && (choice.toLowerCase().charAt(0) != 'y' && choice.toLowerCase().charAt(0) != 'n'))
			{
				System.out.print("Please specify yes or no: ");
				choice = StemGame.input.next();;
			}
			char chose =  choice.toLowerCase().charAt(0);
			if(chose == 'y')
			{
				int itemChoice = 0;
				for(int i = 0; i < stud.items.size(); i++)
				{
					System.out.printf("[%s] %s %s\n",i,stud.items.get(i).name,stud.items.get(i).description);
				}
				System.out.print("Choose your item: ");
				boolean choseCorrectly = false;
				while(!choseCorrectly)
				{
					while(StemGame.input.hasNextInt())
					{
						itemChoice = StemGame.input.nextInt();
						if(itemChoice >= 0 && itemChoice < stud.items.size())
						{
							choseCorrectly = true;
							break;
						}
						else System.out.print("Please enter an integer within the bounds of your commands!: ");
					}
					if(choseCorrectly) continue;
					else
					{
						System.out.print("Please enter an integer: ");
						StemGame.input.next();
					}
				}
				System.out.println();
				stud.items.get(itemChoice).useItem(stud,prof);
				stud.items.remove(itemChoice);
				System.out.println("\n");
				StemGame.input.nextLine();
			}
			else 
			{
				StemGame.display("Okay, nevermind then!~");
				StemGame.input.nextLine();
			}
		}
	}


	//Prompts the user to buy stuff
	public static void shop(Student stud)
	{
		boolean canAfford = false;
		for(int i = 0; i < itemIndex; i++)
		{
			if(stud.cougarDollars >= costList[i])
			{
				canAfford = true;
				break;
			}
		}
		if(canAfford && stud.items.size() < 3)
		{
			Items[] products = new Items[5];
			products[0] = new Pretzel();
			products[1] = new RedBull();
			products[2] = new Chips();
			products[3] = new Ursinos();
			products[4] = new Ringtone();

			//Print out the products
			for(int i = 0; i < products.length; i++)
			{
				System.out.printf("[%d] %s: %s --> Costs %.2f Courgar Dollars\n",i,products[i].name,products[i].description,products[i].cost);
			}
			System.out.println("YOUR COUGAR DOLLARS: "+stud.cougarDollars);
			//Check to see if the user would like to buy anything
			System.out.print("Would you like to buy an item before the next battle? [y/n]: ");
			String choice = StemGame.input.next();
			System.out.print("");;
			while(StemGame.input.hasNextLine() && (choice.toLowerCase().charAt(0) != 'y' && choice.toLowerCase().charAt(0) != 'n'))
			{
				System.out.print("Please specify yes or no: ");
				choice = StemGame.input.next();;
			}
			char chose =  choice.toLowerCase().charAt(0);
			if(chose == 'y')
			{
				int itemChoice = 0;
				System.out.print("Choose your item: ");
				boolean choseCorrectly = false;
				while(!choseCorrectly)
				{
					while(StemGame.input.hasNextInt())
					{
						itemChoice = StemGame.input.nextInt();
						if((itemChoice >= 0 && itemChoice < products.length)&&(stud.cougarDollars >= products[itemChoice].cost))
						{
							choseCorrectly = true;
							break;
						}
						else System.out.print("Please buy something that exists, or you can actually afford!: ");
					}
					if(choseCorrectly) continue;
					else
					{
						System.out.print("Please enter an integer: ");
						StemGame.input.next();
					}
				}
				System.out.printf("%s purchased %s!~",stud.name,products[itemChoice].name);
				StemGame.input.nextLine();
				StemGame.input.nextLine();
				stud.items.add(products[itemChoice]);
				stud.cougarDollars -= products[itemChoice].cost;
				System.out.println("\n");
			}
			else 
			{
				StemGame.display("Okay, nevermind then!~");
				StemGame.input.nextLine();
			}
		}
		else
		{
			if(stud.items.size() >= 3 && !canAfford)
			{
				StemGame.display("Sorry, you cannot access the store right now!~");
				StemGame.display("You can't afford anything, plus you have no room! Eat some things, don\'t be wasteful!~");
			}
			else if(stud.items.size() >= 3)
			{
				StemGame.display("Sorry, you cannot access the store right now!~");
				StemGame.display("Eat what you\'ve got to use the store next time!~");
			}
			else if(!canAfford)
			{
				StemGame.display("Sorry, you cannot access the store right now!~");
				StemGame.display("Broke college student...You can\'t use the store if you can\'t afford it!~");
			}
		}
	}
}
				

class Pretzel extends Items
{
	public Pretzel()
	{
		name = "Pretzel";
		value = 45;
		description = "Heal for "+value+" HP";
		cost = 3.50;
		for(int i = 0; i < itemIndex; i++)
		{
			if(costList[i] == cost)
			{
				added = true;
				break;
			}
		}
		if(!added) costList[itemIndex++] = cost;
	}

	public void useItem(Student stud, Professor prof)
	{
		System.out.printf("%s used %s, healing for %d damage!~",stud.name,name,value);
		if(stud.HP + value >= stud.maxHP) stud.HP = stud.maxHP;
              	else stud.HP += value;
	}
}
class RedBull extends Items
{
	public RedBull()
	{
		name = "RedBull";
		value = 4;
		description = "Sets your GP to 4.0";
		cost = 2.75;
		for(int i = 0; i < itemIndex; i++)
		{
			if(costList[i] == cost)
			{
				added = true;
				break;
			}
		}
		if(!added) costList[itemIndex++] = cost;
	}

	public void useItem(Student stud, Professor prof)
	{
		System.out.printf("%s\'s GP increased to %d~",stud.name,value);
		stud.GP = (double)value;
	}
}

class Chips extends Items
{
	public Chips()
	{
		name = "Chips";
		value = 30;
		description = "Heal for "+value+" HP";
		cost = 1.50;
		for(int i = 0; i < itemIndex; i++)
		{
			if(costList[i] == cost)
			{
				added = true;
				break;
			}
		}
		if(!added) costList[itemIndex++] = cost;
	}

	public void useItem(Student stud, Professor prof)
	{
		System.out.printf("%s used %s, healing for %d damage!~",stud.name,name,value);
		if(stud.HP + value >= stud.maxHP) stud.HP = stud.maxHP;
              	else stud.HP += value;
	}
}
class Ursinos extends Items
{
	public Ursinos()
	{
		name = "Ursinos";
		value = 85;
		description = "Heal for "+value+" HP";
		cost = 9.50;
		for(int i = 0; i < itemIndex; i++)
		{
			if(costList[i] == cost)
			{
				added = true;
				break;
			}
		}
		if(!added) costList[itemIndex++] = cost;
	}

	public void useItem(Student stud, Professor prof)
	{
		System.out.printf("%s used %s, healing for %d damage!~",stud.name,name,value);
		if(stud.HP + value >= stud.maxHP) stud.HP = stud.maxHP;
              	else stud.HP += value;
	}
}
class Ringtone extends Items
{
	public Ringtone()
	{
		name = "Ringtone";
		value = 40;
		description = "Damages the Professor for "+value+" damage";
		cost = 3.0;
		for(int i = 0; i < itemIndex; i++)
		{
			if(costList[i] == cost)
			{
				added = true;
				break;
			}
		}
		if(!added) costList[itemIndex++] = cost;
	}

	public void useItem(Student stud, Professor prof)
	{
		System.out.printf("%s\'s phone went off! %s took %d damage!~",stud.name,prof.name,value);
		prof.HP -= value;
	}
}
