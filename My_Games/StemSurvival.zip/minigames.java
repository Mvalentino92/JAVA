public class minigames
{
	static String message = "That is incorrect. There\'s no second chances here for input here. It\'s an exam, sorry!";
	public static void main(String[] args)
	{
		CompMath player = new CompMath();
		defeatedFarnum(player);
		defeatedCuesta(player);
		defeatedNan(player);
		defeatedMerrit(player);
		defeatedHayes(player);
		defeatedConiglio(player);
		defeatedR(player);
		defeatedJoiner(player);
	}

	public static boolean validInput(char answer)
	{
		char[] choices = {'A','B','C','D'};
		for(int i = 0; i < choices.length; i++)
		{
			if(answer == choices[i]) return true;
		}
		return false;
	}

	public static void defeatedFarnum(Student stud)
	{
		int correct = 0;
		System.out.println("In linear algebra, what is the Trivial Solution?");
		System.out.println("[A] When no solution exists\n[B] The Eigenvectors\n[C] The zero vector\n[D] The solutin closest in value to zero");
		System.out.print("Your answer: ");
		char answer = StemGame.input.next().charAt(0);
		if(answer == 'C')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		System.out.println();
		//Q2
		System.out.println("i) sin(x)*cos(x)\nii) 13cos(3x)*4cos(3x)\niii) 3sin(2x)*3sin(4x)\niv) cos(2x)*sin(2x)\n"
				+"Which of the following are orthogonal?");
		System.out.println("[A] i,iii and iv\n[B] i,ii, and iv\n[C] ii and iii\n[D] ii and iv");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'A')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Q3
		System.out.println();
		System.out.println("What is the integral of -cos(x)?");
		System.out.println("[A] -sin(x)\n[B] cos(x)\n[C] sin(x)\n[D] -cos(x)");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'A')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Results
		System.out.println();
		if(correct == 3)
		{
			StemGame.display("You aced it!~");
			StemGame.displayln("You are awarded times 1.5 attack for the next battle!~");
			stud.setScale(true,1.5);
		}
		else if(correct == 2)
		{
			StemGame.display("You passed!~");
			StemGame.displayln("You are awarded +40 health before the next battle!~");
			if(stud.HP + 40 >= stud.maxHP) stud.HP = stud.maxHP;
			else stud.HP += 40;
		}
		else StemGame.displayln("You failed. Try harder next time!~");
	}

	public static void defeatedJoiner(Student stud)
	{
		int correct = 0;
		System.out.println("In Java, what will the following print out?\nint number = 4;\nSystem.out.println(++number);");
		System.out.println("[A] 4\n[B] Nothing\n[C] 3\n[D] 5");
		System.out.print("Your answer: ");
		char answer = StemGame.input.next().charAt(0);
		if(answer == 'D')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		System.out.println();
		//Q2
		System.out.println("What is the SI Unit for mass?");
		System.out.println("[A] Grams\n[B] Kilograms\n[C] Meters\n[D] Milligrams");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'B')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Q3
		System.out.println();
		System.out.println("Theorectically if you dropped a ball, and fired a gun from the same height, would the ball\nand bullet hit the ground at "
				+"the same time?");
		System.out.println("[A] Yes\n[B] No");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'A')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Results
		System.out.println();
		if(correct == 3)
		{
			StemGame.display("You aced it!~");
			StemGame.displayln("You are awarded 0.8 GP reduction and 30 health for the next battle!~");
			stud.setScale(false,0.8);
			if(stud.HP + 30 >= stud.maxHP) stud.HP = stud.maxHP;
			else stud.HP += 30;
			
		}
		else if(correct == 2)
		{
			StemGame.display("You passed!~");
			StemGame.displayln("You are awarded +2 GP before the next battle!~");
			if(stud.GP + 2 >= 4.0) stud.GP = 4.0;
			else stud.GP += 2;	
		}
		else StemGame.displayln("You failed. Try harder next time!~");
	}

	public static void defeatedR(Student stud)
	{
		int correct = 0;
		System.out.println("What is the most electronegative atom?");
		System.out.println("[A] Oxygen\n[B] Carbon\n[C] Chlorine\n[D] Fluorine");
		System.out.print("Your answer: ");
		char answer = StemGame.input.next().charAt(0);
		if(answer == 'D')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		System.out.println();
		//Q2
		System.out.println("If you were to write the condensed electron configuration for Arsenic, which noble has would you use?");
		System.out.println("[A] Ne\n[B] Xe\n[C] Ar\n[D] Kr");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'C')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Q3
		System.out.println();
		System.out.println("What is the charge of Sulfate?");
		System.out.println("[A] 1-\n[B] 2+\n[C] 2-\n[D] 3-");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'C')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Results
		System.out.println();
		if(correct == 3)
		{
			StemGame.display("You aced it!~");
			StemGame.displayln("You are awarded times 1.2 attack, +20 HP and +3 GP for the next battle!~");
			stud.setScale(true,1.2);
			if(stud.HP + 20 >= stud.maxHP) stud.HP = stud.maxHP;
			else stud.HP += 20;
			if(stud.GP + 3 >= 4.0) stud.GP = 4.0;
			else stud.GP += 3;
		}
		else if(correct == 2)
		{
			StemGame.display("You passed!~");
			StemGame.displayln("You are awarded +50 health before the next battle!~");
			if(stud.HP + 50 >= stud.maxHP) stud.HP = stud.maxHP;
			else stud.HP += 50;
		}
		else StemGame.displayln("You failed. Try harder next time!~");
	}

	public static void defeatedConiglio(Student stud)
	{
		int correct = 0;
		System.out.println("What cellular machinery that \"unzips\" the double helix during DNA replication?");
		System.out.println("[A] DNA Polymerase\n[B] Helicase\n[C] Cleavase\n[D] Topoismomerase");
		System.out.print("Your answer: ");
		char answer = StemGame.input.next().charAt(0);
		if(answer == 'B')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		System.out.println();
		//Q2
		System.out.println("The overall three dimensional structure of polypeptide is called it\'s?");
		System.out.println("[A] Secondary Structure\n[B] Quaternary Structure\n[C] Primary Structure\n[D] Tertiary Structure");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'D')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Q3
		System.out.println();
		System.out.println("What is the final phase of cell division?");
		System.out.println("[A] Telophase\n[B] Prophase\n[C] Prometaphase\n[D] Anaphase");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'A')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Results
		System.out.println();
		if(correct == 3)
		{
			StemGame.display("You aced it!~");
			StemGame.displayln("You are awarded 0.5 GP consumption for the next battle!!~");
			stud.setScale(false,0.5);
		}
		else if(correct == 2)
		{
			StemGame.display("You passed!~");
			StemGame.displayln("You are awarded 0.85 GP consumption for the next battle!!~");
			stud.setScale(false,0.85);
		}
		else StemGame.displayln("You failed. Try harder next time!~");
	}

	public static void defeatedHayes(Student stud)
	{
		int correct = 0;
		System.out.println("You have a 100mL solution, that is 50X concentration.\nYou need to prepare a 500mL solution that is 2X concentration."
				+"\nHow much of the original 50X solution do you need to add to what amount of water?");
		System.out.println("[A] 40mL of original | 460mL water\n[B] 20mL or original | 480mL water\n"
				+"[C] 460mL of original | 40mL water\n[D] 25mL of original | 475mL of water");
		System.out.print("Your answer: ");
		char answer = StemGame.input.next().charAt(0);
		if(answer == 'B')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		System.out.println();
		//Q2
		System.out.println("What is the overall charge of DNA?");
		System.out.println("[A] Positive\n[B] Negative\n[C] Neutral\n");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'B')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Q3
		System.out.println();
		System.out.println("Which of the following represents a start codon?");
		System.out.println("[A] AGG\n[B] CTT\n[C] ATC\n[D] ATG");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'D')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Results
		System.out.println();
		if(correct == 3)
		{
			StemGame.display("You aced it!~");
			StemGame.displayln("You are awarded times 1.4 attack, and a 4.0 for the next battle!~");
			stud.setScale(true,1.4);
			stud.GP = 4.0;
		}
		else if(correct == 2)
		{
			StemGame.display("You passed!~");
			StemGame.displayln("You are awarded +40 health before the next battle!~");
			if(stud.HP + 40 >= stud.maxHP) stud.HP = stud.maxHP;
			else stud.HP += 40;
		}
		else StemGame.displayln("You failed. Try harder next time!~");
	}

	public static void defeatedMerrit(Student stud)
	{
		int correct = 0;
		System.out.println("How many pi bonds are present in a Triple Bond?");
		System.out.println("[A] 1\n[B] 2\n[C] 3\n[D] None");
		System.out.print("Your answer: ");
		char answer = StemGame.input.next().charAt(0);
		if(answer == 'B')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		System.out.println();
		//Q2
		System.out.println("What functional group does CH3 represent?");
		System.out.println("[A] Methyl\n[B] Carbonyl\n[C] Amino\n[D] Hydroxyl");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'A')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Q3
		System.out.println();
		System.out.println("What is the hydridization of a central atom with the electron geomeotry tetrahedrel?");
		System.out.println("[A] sp\n[B] sp2\n[C] sp3\n[D] sp4");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'C')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Results
		System.out.println();
		if(correct == 3)
		{
			StemGame.display("You aced it!~");
			StemGame.displayln("You are awarded +100 HP for the next battle!!~");
			if(stud.HP + 100 >= stud.maxHP) stud.HP = stud.maxHP;
			else stud.HP += 100;
		}
		else if(correct == 2)
		{
			StemGame.display("You passed!~");
			StemGame.displayln("You are awarded +50 health before the next battle!~");
			if(stud.HP + 50 >= stud.maxHP) stud.HP = stud.maxHP;
			else stud.HP += 50;
		}
		else StemGame.displayln("You failed. Try harder next time!~");
	}

	public static void defeatedNan(Student stud)
	{
		int correct = 0;
		System.out.println("How many Metacarpel bones are in the human body?");
		System.out.println("[A] 10\n[B] 2\n[C] 5\n[D] 20");
		System.out.print("Your answer: ");
		char answer = StemGame.input.next().charAt(0);
		if(answer == 'A')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		System.out.println();
		//Q2
		System.out.println("Is a sporophyte diploid or haploid?");
		System.out.println("[A] Diploid\n[B] Haploid\n[C] Neither");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'A')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Q3
		System.out.println();
		System.out.println("What is the first eon on earths geologic time scale?");
		System.out.println("[A] Archean\n[B] Proterozoic\n[C] Phanerozoic\n[D] Hadean");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'D')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Results
		System.out.println();
		if(correct == 3)
		{
			StemGame.display("You aced it!~");
			StemGame.displayln("You are awarded times 1.35 attack, and 0.75 GP consumption for the next battle!~");
			stud.setScale(true,1.35);
			stud.setScale(false,0.75);
		}
		else if(correct == 2)
		{
			StemGame.display("You passed!~");
			StemGame.displayln("You are awarded +40 health before the next battle!~");
			if(stud.HP + 40 >= stud.maxHP) stud.HP = stud.maxHP;
			else stud.HP += 40;
		}
		else StemGame.displayln("You failed. Try harder next time!~");
	}

	public static void defeatedCuesta(Student stud)
	{
		int correct = 0;
		System.out.println("What is HClO2?");
		System.out.println("[A] Perchloric Acid\n[B] Chlorous Acid\n[C] Hypochlorous Acid\n[D] Chloric Acid");
		System.out.print("Your answer: ");
		char answer = StemGame.input.next().charAt(0);
		if(answer == 'B')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		System.out.println();
		//Q2
		System.out.println("What is the speed of light?");
		System.out.println("[A] 3e7\n[B] 3e10\n[C] 3e8\n[D] 3e-7");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'C')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Q3
		System.out.println();
		System.out.println("What is momentum?");
		System.out.println("[A] Mass*Speed\n[B] Mass*Torque\n[C] Inertia*speed\n[D] Mass*Velocity");
		System.out.print("Your answer: ");
		answer = StemGame.input.next().charAt(0);
		if(answer == 'D')
		{
			System.out.print("Correct!!");
			correct++;
		}
		else if(!validInput(answer)) System.out.print(message);
		else System.out.print("That is not correct.");
		StemGame.input.nextLine();
		StemGame.input.nextLine();
		//Results
		System.out.println();
		if(correct == 3)
		{
			StemGame.display("You aced it!~");
			StemGame.displayln("You are awarded times 1.2 attack for the next battle!~");
			stud.setScale(true,1.2);
		}
		else if(correct == 2)
		{
			StemGame.display("You passed!~");
			StemGame.displayln("You are awarded +30 health before the next battle!~");
			if(stud.HP + 30 >= stud.maxHP) stud.HP = stud.maxHP;
			else stud.HP += 30;
		}
		else StemGame.displayln("You failed. Try harder next time!~");
	}
}
