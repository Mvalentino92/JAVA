import java.util.*; 
import java.math.*; 
import java.io.*; 

public class FindMatches
{
	//Converts the string of letters to numbers.
	public static int[] convert2Numbers(String letters)
	{
		letters = letters.toUpperCase();
		int[] array = new int[7];
		for(int i = 0; i < array.length; i++)
		{
			array[i] = (int)letters.charAt(i);
		}
		return array;
	}

	/*Gererates the matrix that holds the following information. (Both methods prepMatrix and fillMatrix populate the matrix).
	 * Index 0: Whether or not this is still a possible word my letters can make. (0 == valid, -1 == dead)
	 * Index 1-7: The actual letters of this scrabble word.
	 * Index 8-14: My letters. Any that have been used towards confirming this scrabble word may be valid, are marked -1.*/
	public static int[][] prepMatrix(String fileName) throws Exception
	{
		//Set up matrix and load file.
		int[][] matrix = new int[34167][15];
		File inputFile = new File(fileName);
		Scanner input = new Scanner(inputFile);

		//Populate initial elements with values
		for(int i = 0; i < matrix.length; i++)
		{
			for(int j = 1; j < 8; j++) matrix[i][j] = input.nextInt();
		}
		return matrix;
	}

	public static void fillMatrix(int[][] matrix, int[] letters)
	{
		//Fill each row in the matrix with the users letters
		for(int i = 0; i < matrix.length; i++)
		{
			for(int j = 8; j < 15; j++) matrix[i][j] = letters[j-8];
		}
	}

	public static void printMatches(int[][] matrix)
	{
		//Iterations (not column!)
		for(int i = 0; i < 7; i++)
		{
			//Row
			for(int j = 0; j < matrix.length; j++)
			{
				//If this row is already dead, move on.
				if(matrix[j][0] == -1) continue;
				
				//Otherwise, try and get a match on this letter, from the remaining letters.
				int count = 0;
				int letterToMatch = matrix[j][i+1];
				for(int k = 8; k < 15; k++)
				{
					if(matrix[j][k] != letterToMatch) count++;
					else
					{
						matrix[j][k] = -1;
						break;
					}
				}
				//If we went through all the letters, with no match, mark this row as dead.
				if(count == 7) matrix[j][0] = -1;
			}
		}

		//The only remaining rows should be ones that are valid words. Iterate and print them.
		for(int i = 0; i < matrix.length; i++)
		{
			if(matrix[i][0] == 0)
			{
				for(int j = 1; j < 8; j++) System.out.print((char)matrix[i][j]);	
				System.out.println();
			}
		}
	}
	
	public static void main(String[] args) throws Exception
	{
		//Prompt for letters and prep matrix while user types.
		Scanner getWord = new Scanner(System.in);
		System.out.print("Enter your 7 letters: ");
		int[][] matrix = prepMatrix("seven2numbers.txt");
		String letters = getWord.nextLine();

		//Finish filling the matrix.
		int[] myLetters = convert2Numbers(letters);
		fillMatrix(matrix,myLetters);

		//Print all the matches
		printMatches(matrix);
	}
}
