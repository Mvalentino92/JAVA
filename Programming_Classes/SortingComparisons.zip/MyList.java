import java.util.*;
interface MyList<E>
{
	//Add an element at end
	public boolean add(E e);

	//Add an element at index
	public void add(int index, E e);

	//Retrieve element at specified index
	public E get(int index);

	//Retrieve the first index of matching element
	public int indexOf(E e);

	//Retrieve the last index of the matching element
	public int lastIndexOf(E e);

	//Remove the element at the specified index
	public E remove(int index);

	//Replace the old element with new element at specified index and return old
	public E set(int index, E e);

	//Checks if the list is empty
	public boolean isEmpty();

	//Returns the size
	public int size();
}
