import java.math.*;
import java.util.*;

//Custom Time objects, to sort the computation times of the algorithm
class Times
{
	double time;
	String algorithm;

	public Times(double time, String algorithm)
	{
		this.time = time;
		this.algorithm = algorithm;
	}

	void printResults()
	{
		System.out.println(algorithm+" took "+time+" seconds.");
	}
}

//Custom Comparator for sorting Time objects by their "time" variable.
class TimeComparator implements Comparator<Times>
{
	public int compare(Times a, Times b)
	{
		double result = a.time - b.time;
		if(result < 0) return -1;
		else if(result > 0) return 1;
		else return 0;
	}
}

public class SortCompare
{
	//Iterative Selection Sort
	public static <E extends Comparable<E>> void SelectionSort(E[] arr)
	{
		int minDex;
		E temp, min;
		for(int i = 0; i < arr.length-1; i++)
		{
			min = arr[i];
			minDex = i;
			for(int j = i + 1; j < arr.length; j++)
			{
				if(arr[j].compareTo(min) < 0)
				{
					min = arr[j];
					minDex = j;
				}
			}
			temp = arr[i];
			arr[i] = min;
			arr[minDex] = temp;
		}
	}

	//Recursive Selection Sort
	public static <E extends Comparable<E>> void rSelectionSort(E[] arr, int index)
	{
		if(index == arr.length - 1) return;
		E min = arr[index];
		E temp;
		int minDex = index;
		for(int j = index + 1; j < arr.length; j++)
		{
			if(arr[j].compareTo(min) < 0)
			{
				min = arr[j];
				minDex = j;
			}
		}
		temp = arr[index];
		arr[index] = min;
		arr[minDex] = temp;
		rSelectionSort(arr,index+1);
	}

	//Iterative BubbleSort
	public static <E extends Comparable<E>> void BubbleSort(E[] arr)
	{
		int index = arr.length - 1;
		boolean isSorted = false;
		E temp;

		while(!isSorted)
		{
			isSorted = true;
			for(int i = 0; i < index; i++)
			{
				if(arr[i].compareTo(arr[i+1]) > 0)
				{
					temp = arr[i+1];
					arr[i+1] = arr[i];
					arr[i] = temp;
					isSorted = false;
				}
			}
			index--;
		}
	}

	//Recursive BubbleSort
	public static <E extends Comparable<E>> void rBubs(E[] arr, boolean isSorted, int index)
	{
		if(isSorted) return;
		isSorted = true;
		E temp;

		for(int i = 0; i < index; i++)
		{
			if(arr[i].compareTo(arr[i+1]) > 0)
			{
					temp = arr[i+1];
					arr[i+1] = arr[i];
					arr[i] = temp;
					isSorted = false;
			}
		}
		rBubs(arr,isSorted,index-1);
	}

	//Caller function for Recursive BubbleSort
	public static <E extends Comparable<E>> void rBubbleSort(E[] arr) {rBubs(arr,false,arr.length-1);}

	//Iterative Insertion Sort (out of place)
	public static Integer[] insertionSort(Integer[] arr)
	{
		//Create return arr
		Integer[] retval = new Integer[arr.length];
		int size = 0;

		//Begin to insert
		for(int i = 0; i < arr.length; i++)
		{
			Integer val = arr[i];
			int j = 0;
			while(j < size)
			{
				if(val.compareTo(retval[j]) > 0) j++;
				else break;
			}
			for(int k = j; k < size; k++)
			{
				int temp = retval[k];
				retval[k] = val;
				val = temp;
			}
			retval[size++] = val;
		}
		return retval;
	}

	//Recursive InsertionSort, (out of place)
	public static void rIS(Integer[] arr,Integer[] retval,int index,int size)
	{
		//Base case
		if(index == arr.length) return;

		Integer val = arr[index];
		int j = 0;
		while(j < size)
		{
			if(val.compareTo(retval[j]) > 0) j++;
			else break;
		}
		for(int k = j; k < size; k++)
		{
			int temp = retval[k];
			retval[k] = val;
			val = temp;
		}
		retval[size] = val;
		rIS(arr,retval,index+1,size+1);
	}

	//Recursive Insertion helper
	public static Integer[] recursiveInsertionSort(Integer[] arr)
	{
		Integer[] retval = new Integer[arr.length];
		rIS(arr,retval,0,0);
		return retval;
	}

	//**********************RADIX SORT******************************
	//Stitches together all the buckets into one list
	public static ArrayList<Integer> stitch(ArrayList<ArrayList<Integer>> buckets)
	{
		ArrayList<Integer> retval = new ArrayList<>();
		for(int i = 0; i < buckets.size(); i++)
		{
			ArrayList<Integer> current = buckets.get(i);
			for(int j = 0; j < current.size(); j++) retval.add(current.get(j));
		}
		return retval;
	}
	
	//Return the number broken down to the current depth (or just 0, if that depth is overshot)
	public static int getDigit(Integer n,int place)
	{
		int retval = 0;
		n /= (int)(Math.pow(10,place-1));
		return n % 10;
	}

	//Sorts elements into buckets based on the current depth
	public static ArrayList<ArrayList<Integer>> getBuckets(ArrayList<Integer> list,int place)
	{
		//Retval
		ArrayList<ArrayList<Integer>> retval = new ArrayList<ArrayList<Integer>>();

		//If you can keep going, do so, otherwise add the list to retval
		if(place > 0)
		{
			//Create the buckets
			ArrayList<ArrayList<Integer>> buckets = new ArrayList<>();
			for(int i = 0; i < 10; i++) buckets.add(new ArrayList<Integer>());

			//Go through the numbers and put them relevant buckets
			for(Integer num : list) buckets.get(getDigit(num,place)).add(num);

			//Stitch all buckets together
			for(ArrayList<Integer> bucket : buckets) retval.add(stitch(getBuckets(bucket,place-1)));
		}
		else retval.add(list);

		//Return
		return retval;
	}

	//iStitch
	public static Integer[] iStitch(ArrayList<ArrayList<Integer>> buckets, int len)
	{
		//Return arr
		Integer[] retval = new Integer[len];
		int index = 0;

		//Stitch together buckets
		for(int i = 0; i < buckets.size(); i++)
		{
			ArrayList<Integer> current = buckets.get(i);
			for(int j = 0; j < current.size(); j++) retval[index++] = current.get(j);
			current.clear();
		}
		return retval;
	}

	//Iterative Radix Sort
	public static Integer[] iRadixSort(Integer[] arr)
	{
		//Create the buckets that will hold the digits
		ArrayList<ArrayList<Integer>> buckets = new ArrayList<>();
		for(int i = 0; i < 10; i++) buckets.add(new ArrayList<Integer>());

		//Create boolean to track if all were placed into the first bucket (meaning were done!)
		//Create place variable, starting at 1
		//Grab the length of the list
		boolean allZero = false;
		int place = 1;
		int len = arr.length;

		/*Begin to iterate, and only stop if every is placed in first bucket*/
		while(!allZero)
		{
			//Add all numbers to respective buckets
			for(int i = 0; i < len; i++)
			{
				buckets.get(getDigit(arr[i],place)).add(arr[i]);
			}

			//If all were placed in the first bucket return,
			//Otherwise, keep going
			if(buckets.get(0).size() == len) allZero = true;
			else
			{
				//Stitch buckets together, and increment place
				arr = iStitch(buckets,len);
				place++;
			}
		}
		return arr;
	}

	//Helper function for recursive radix sort
	public static ArrayList<Integer> rad(ArrayList<Integer> list,int depth)
	{
		return stitch(getBuckets(list,depth));
	}

	/*Partition function. Will partition around the specified element in place
	 * Needs the starting and last index (to simulate splitting up the array),
	 * Will return the index where the element of question was finally places.
	 * uses the last element as the partitioning element*/
	public static int partition(Integer[] arr, int start, int end)
	{
		Integer temp;
		while(start < end - 1)
		{
			//If leftmost is larger do a double swap
			if(arr[start].compareTo(arr[end]) > 0)
			{
				temp = arr[start];
				arr[start] = arr[end-1];
				arr[end-1] = arr[end];
				arr[end] = temp;
				end--;
			}
			//else just move start forward
			else start++;
		}
		//Swap once if applicable for last case
		if(arr[start].compareTo(arr[end]) > 0)
		{
			temp = arr[start];
			arr[start] = arr[end];
			arr[end] = temp;
			end--;
		}
		return end;
	}

	/*Iterative quickSort, (recursive version simulated by using an auxilary stack
	 * Use 2 stacks. One for START and one for END.
	 * START will only have one value, and will be passed to partition() everytime along with the 
	 * result of the last partition() call. That call result will also be added to stack.
	 * Once the result matches the only element on the START, then pop from START,
	 * pop from END and add 1 to it (to get the first one that isn't the matching one), 
	 * and push that popped value to START.
	 * It is now the NEW ONLY START value. Rinse and repeat until the END stack is empty.
	 * Also, use peek() for everything.*/
	public static void iQS(Integer[] arr)
	{
		//Make the start variable, set to 0
		Integer start = 0;

		//Make the end Stack, and add initial element
		Stack<Integer> end = new Stack<>();
		end.push(arr.length);

		//Helps track the left-most values in stack
		int first = 0;

		//While the end stack has elements, keep sorting
		while(!end.empty())
		{
			//Get new end
			int newEnd = partition(arr,(int)start,(int)end.peek()-1);

			//Check if it's equal to start, if it is, do the swap
			if(start == newEnd)
			{
				if(start == first++)
				{
					start++;
					if(end.peek() <= start) end.pop();
				}
				else start = end.pop();
			}
			//If not, then push it to end
			else end.push(newEnd);
		}
		return;
	}

	//Actual quickSort algorithm
	public static void QS(Integer[] arr,int start, int end)
	{
		//If base case return
		if(start >= end) return;
		
		//Otherwise call partition with the bounds,
		//get new bound, and recursively call quickSort	
		int newEnd = partition(arr,start,end);
		QS(arr,start,newEnd-1);
		QS(arr,newEnd+1,end);
	}

	//Helper function to call it recursive quicksort
	public static void quickSort(Integer[] arr)
	{
		QS(arr,0,arr.length-1);
	}

	//Merge function
	public static Integer[] merge(Integer[] l, Integer[] r)
	{
		//Init indexes and return new Student[]
		Integer[] retval = new Integer[l.length + r.length];
		int i = 0;
		int j = 0;
		int index = 0;
		
		//Loop through and add values
		while(i < l.length && j < r.length)
		{
			if(l[i].compareTo(r[j]) <= 0) retval[index++] = l[i++];
			else retval[index++] = r[j++];
		}

		//Check to see who finished first, then add the rest of the other person
		if(i == l.length)
		{
			for(int k = j; k < r.length; k++) retval[index++] = r[k];;
		}
		else
		{
			for(int k = i; k < l.length; k++) retval[index++] = l[k];
		}

		//Return the new, and sorted ArrayList
		return retval;
	}
	
	//Performs the mergeSort algorithm
	public static Integer[] MS(Integer[] arr)
	{
		//Base case
		if(arr.length <= 1) return arr;

		//Partition into two arrays, and recursively call it
		int halfWay = arr.length/2;
		Integer[] l = new Integer[halfWay];
		Integer[] r = new Integer[arr.length - halfWay];

		//Set arrays
		int lDex = 0;
		int rDex = 0;
		for(int i = 0; i < halfWay; i++) l[lDex++] = arr[i];;
		for(int i = halfWay; i < arr.length; i++) r[rDex++] = arr[i];

		//Recursively call mergesort
		return merge(MS(l),MS(r));
	}

	//Merges for Iterative MergeSort
	public static void iMerge(Integer[] l, Integer[] r, Integer[] arr, int index)
	{
		//Init indexes
		int i = 0;
		int j = 0;
		
		//Loop through and add values
		while(i < l.length && j < r.length)
		{
			if(l[i].compareTo(r[j]) <= 0) arr[index++] = l[i++];
			else arr[index++] = r[j++];
		}

		//Check to see who finished first, then add the rest of the other person
		if(i == l.length)
		{
			for(int k = j; k < r.length; k++) arr[index++] = r[k];;
		}
		else
		{
			for(int k = i; k < l.length; k++) arr[index++] = l[k];
		}
		return;
	}

	//Iterative mergesort function
	public static void iMergeSort(Integer[] arr)
	{
		//Power of 2 to iterate by, and length of array, and half + 1.
		int pow2 = 1;
		int length = arr.length;

		//Iterate in powers of 2 while those powers are less than the length/2 + 1
		while(pow2 < length/2 + 1)
		{
			//Calculate the remainder (r) and the bound
			int rem = length % (pow2*2);
			int bound = length - rem;

			//Begin to iterate the array in strides of the pow2*2
			int i;
			for(i = 0; i < bound; i += pow2*2)
			{
				//Left
				Integer[] l = new Integer[pow2];
				for(int j = 0; j < l.length; j++) l[j] = arr[i+j];

				//Right
				Integer[] r = new Integer[pow2];
				for(int k = 0; k < r.length; k++) r[k] = arr[i+k+pow2];

				//Get merged
				iMerge(l,r,arr,i);
			}
			/*Handle if there is remainders or not*/
			pow2 <<= 1;
			i -= pow2;
			if(rem == 0) continue;

			//Left
			Integer[] l = new Integer[pow2];
			for(int j = 0; j < l.length; j++) l[j] = arr[i+j];

			//Right
			Integer[] r = new Integer[rem];
			for(int k = 0; k < r.length; k++) r[k] = arr[i+k+pow2];

			//Get merged
			iMerge(l,r,arr,i);
		}
	}

	public static void main(String[] args)
	{
		//Keep tally of who was in first the most
		HashMap<String,Integer> first = new HashMap<>();
		first.put("Iterative QuickSort",0);
		first.put("Recursive QuickSort",0);
		first.put("Recursive MergeSort",0);
		first.put("Iterative MergeSort",0);
		first.put("HeapSort",0);
		first.put("PeapSort",0);
		first.put("Iterative RadixSort",0);
		first.put("Recursive RadixSort",0);
		first.put("Linked InsertionSort",0);
		first.put("Iterative InsertionSort",0);
		first.put("Iterative BubbleSort",0);
		first.put("Recursive SelectionSort",0);
		first.put("Iterative SelectionSort",0);
		first.put("Java's Arrays.sort()",0);
		first.put("Recursive InsertionSort",0);

		//Inputs and depth for recursive radix sort
		int[] inputs = {10,100,1000,10000,32768,100000,1000000,(int)(Math.pow(2,21)),
			       (int)(Math.pow(2,22)),(int)(Math.pow(2,23)),10000000};
		//int[] depths = {3,3,3,3,3,3,3,3,3,3,3};
		int[] depths = {1,2,3,4,5,5,6,6,7,7,7};

		/*Loops through all the inputs, and sorts the current list using all sorting
		 * algorithms. Compares every list to the TRUE value list (sorted by java),
		 * to ensure everything is sorted correctly. Tracks the computation time of each 
		 * algorithm, and orders them based on performance every iteration.
		 * Finally, prints the algorithm who placed first the most*/
		for(int i = 0; i < inputs.length; i++)
		{
			//Times and boolean for if were doing the bad sorting algorithms
			ArrayList<Times> times = new ArrayList<>();
			boolean doBad = i < 4 ? true : false;

			//Get array of numbers to be sorted
			Integer[] TRUE = new Integer[inputs[i]];
			Integer[] qs = new Integer[TRUE.length];
			Integer[] iqs = new Integer[TRUE.length];
			Integer[] rm = new Integer[TRUE.length];
			Integer[] im = new Integer[TRUE.length];
			Integer[] irs = new Integer[TRUE.length];
			ArrayList<Integer> rs = new ArrayList<>();
			MyLinkedList<Integer> li = new MyLinkedList<>();
			Integer[] is = new Integer[1];
			Integer[] ris = new Integer[1];
			Integer[] rbs = new Integer[1];
			Integer[] ibs = new Integer[1];
			Integer[] rss = new Integer[1];
			Integer[] iss = new Integer[1];

			//Only truly allocate bad ones if current list is short
			if(doBad)
			{
				is = new Integer[TRUE.length];
				ris = new Integer[TRUE.length];
				rbs = new Integer[TRUE.length];
				ibs = new Integer[TRUE.length];
				rss = new Integer[TRUE.length];
				iss = new Integer[TRUE.length];
			}

			//Populate the arrays
			for(int j = 0; j < TRUE.length; j++)
			{
				TRUE[j] = Integer.valueOf((int)(Math.random()*(inputs[i]/3)));
				iqs[j] = TRUE[j];
				qs[j] = TRUE[j];
				rm[j] = TRUE[j];
				im[j] = TRUE[j];
				irs[j] = TRUE[j];
				rs.add(TRUE[j]);
				if(doBad) //Only populate bad if short list
				{
					li.add(TRUE[j]);
					is[j] = TRUE[j];
					ris[j] = TRUE[j];
					rbs[j] = TRUE[j];
					ibs[j] = TRUE[j];
					rss[j] = TRUE[j];
					iss[j] = TRUE[j];
				}

			}

			//Iterative QuickSort
			double iqsStart = System.nanoTime();
			iQS(iqs);
			double iqsTime = (System.nanoTime() - iqsStart)/1e9;
			times.add(new Times(iqsTime,"Iterative QuickSort"));

			//Recursive QuickSort
			double qsStart = System.nanoTime();
			quickSort(qs);
			double qsTime = (System.nanoTime() - qsStart)/1e9;
			times.add(new Times(qsTime,"Recursive QuickSort"));

			//MergeSort Recursive
			double rmStart = System.nanoTime();
			rm = MS(rm);
			double rmTime = (System.nanoTime() - rmStart)/1e9;
			times.add(new Times(rmTime,"Recursive MergeSort"));

			//MergeSort Iterative
			double imStart = System.nanoTime();
			iMergeSort(im);
			double imTime = (System.nanoTime() - imStart)/1e9;
			times.add(new Times(imTime,"Iterative MergeSort"));

			//Heap
			Heap<Integer> heap = new Heap<>();
			Integer[] sortedHeap = new Integer[TRUE.length];
			double heapStart = System.nanoTime();
			for(int k = 0; k < TRUE.length; k++) heap.add(TRUE[k]);
			for(int k = 0; k < TRUE.length; k++) sortedHeap[TRUE.length - 1 - k] = heap.remove();
			double heapTime = (System.nanoTime() - heapStart)/1e9;
			times.add(new Times(heapTime,"HeapSort"));

			//Peap
			Peap<Integer> peap = new Peap<>();
			Integer[] sortedPeap = new Integer[TRUE.length];
			double peapStart = System.nanoTime();
			for(int k = 0; k < TRUE.length; k++) peap.add(TRUE[k]);
			for(int k = 0; k < TRUE.length; k++) sortedPeap[TRUE.length - 1 - k] = peap.remove();
			double peapTime = (System.nanoTime() - peapStart)/1e9;
			times.add(new Times(peapTime,"PeapSort"));

			//Iterative radix
			double iRadixStart = System.nanoTime();
			irs = iRadixSort(irs);
			double iRadixTime = (System.nanoTime() - iRadixStart)/1e9;
			times.add(new Times(iRadixTime,"Iterative RadixSort"));

			//Radix
			double radixStart = System.nanoTime();
			rs = rad(rs,depths[i]);
			double radixTime = (System.nanoTime() - radixStart)/1e9;
			times.add(new Times(radixTime,"Recursive RadixSort"));

			if(doBad)
			{
				//Linked
				double liStart = System.nanoTime();
				li.iSort();
				double liTime = (System.nanoTime() - liStart)/1e9;
				times.add(new Times(liTime,"Linked InsertionSort"));

				//Iter Insert
				double isStart = System.nanoTime();
				is = insertionSort(is);
				double isTime = (System.nanoTime() - isStart)/1e9;
				times.add(new Times(isTime,"Iterative InsertionSort"));

				//Recur Insert
				double risStart = System.nanoTime();
				ris = recursiveInsertionSort(ris);
				double risTime = (System.nanoTime() - risStart)/1e9;
				times.add(new Times(risTime,"Recursive InsertionSort"));

				//Recur bubble
				double rbsStart = System.nanoTime();
				rBubbleSort(rbs);
				double rbsTime = (System.nanoTime() - rbsStart)/1e9;
				times.add(new Times(rbsTime,"Recursive BubbleSort"));

				//Iter Bubble
				double ibsStart = System.nanoTime();
				BubbleSort(ibs);
				double ibsTime = (System.nanoTime() - ibsStart)/1e9;
				times.add(new Times(ibsTime,"Iterative BubbleSort"));

				//Recur Selec
				double rssStart = System.nanoTime();
				rSelectionSort(rss,0);
				double rssTime = (System.nanoTime() - rssStart)/1e9;
				times.add(new Times(rssTime,"Recursive SelectionSort"));

				//Iter Selection
				double issStart = System.nanoTime();
				SelectionSort(iss);
				double issTime = (System.nanoTime() - issStart)/1e9;
				times.add(new Times(issTime,"Iterative SelectionSort"));
			}

			//Javas Arrays.sort()
			double javaStart = System.nanoTime();
			Arrays.sort(TRUE);
			double javaTime = (System.nanoTime() - javaStart)/1e9;
			times.add(new Times(javaTime,"Java's Arrays.sort()"));

			//Check if all correct before printing
			for(int j = 0; j < TRUE.length; j++)
			{
				Integer x = doBad ? li.get(j) : TRUE[j];
				Integer x2 = doBad ? is[j] : TRUE[j];
				Integer x3 = doBad ? ris[j] : TRUE[j];
				Integer x4 = doBad ? rbs[j] : TRUE[j];
				Integer x5 = doBad ? ibs[j] : TRUE[j];
				Integer x6 = doBad ? rss[j] : TRUE[j];
				Integer x7 = doBad ? iss[j] : TRUE[j];
				if(TRUE[j].compareTo(iqs[j]) != 0 ||
				   TRUE[j].compareTo(qs[j]) != 0 ||
			           TRUE[j].compareTo(rm[j]) != 0 ||
				   TRUE[j].compareTo(im[j]) != 0 ||
				   TRUE[j].compareTo(sortedHeap[j]) != 0 ||
				   TRUE[j].compareTo(sortedPeap[j]) != 0 ||
				   TRUE[j].compareTo(irs[j]) != 0 ||
				   TRUE[j].compareTo(rs.get(j)) != 0 ||
				   TRUE[j].compareTo(x7) != 0 ||
				   TRUE[j].compareTo(x6) != 0 ||
				   TRUE[j].compareTo(x5) != 0 ||
				   TRUE[j].compareTo(x4) != 0 ||
				   TRUE[j].compareTo(x3) != 0 ||
				   TRUE[j].compareTo(x2) != 0 ||
				   TRUE[j].compareTo(x) != 0)
				{
					System.out.println("SORTED INCORRECTLY!");
					System.exit(1);
				}
			}
			System.out.println("Sorting "+TRUE.length+" elements: ");
			Collections.sort(times,new TimeComparator());
			int place = 1;
			for(Times time : times)
			{
				if(place == 1)
				{
					first.replace(time.algorithm,first.get(time.algorithm)+1);
				}
				System.out.print(place+") ");
				place++;
				time.printResults();
			}
			System.out.println();
		}
		//Grab the one with most first place wins
		Set<String> keys = first.keySet();
		int max = 0;
		String winner = "";
		for(String key : keys)
		{
			if(first.get(key) > max)
			{
				max = first.get(key);
				winner = key;
			}
		}
		System.out.println(winner+" is best overall performing algorithm," 
				   +" placing first "+max+"/"+inputs.length+" times.");
	}
}
