import java.util.*; 
import java.math.*; 
import java.io.*; 

public class Heap<E extends Comparable<E>>
{
	//ArrayList that will represent the heap
	private ArrayList<E> arr = new ArrayList<>();

	//Constructor
	public Heap(){}
	
	//Get size
	int getSize(){return arr.size();}

	//Swap
	void swap(int a, int b)
	{
		E temp = arr.get(b);
		arr.set(b,arr.get(a));
		arr.set(a,temp);
	}

	//Get the head of this Heap without removing it
	E getHead()
	{
		if(arr.size() == 0) return null;
		else return arr.get(0);
	}

	//Checks if this is empty
	boolean isEmptyHeap() {return arr.size() == 0;}


			/*Only 2 methods, add and remove*/
	void add(E e)
	{
		arr.add(e);
		int current = arr.size()-1;
		int parent = (current - 1)/2;
		if(parent < 0) return;

		//BubbleUp while you can
		while(arr.get(current).compareTo(arr.get(parent)) > 0)
		{
			swap(current,parent);
			current = parent;
			parent = (current - 1)/2;
			if(parent < 0) break;
		}
	}

	E remove()
	{
		//Remove last return if now empty
		swap(0,arr.size()-1);
		E retval = arr.remove(arr.size()-1);
		if(arr.size() == 0) return retval;

		//Start from the stop and bubbledown, pick larger child to swap with.
		int parent = 0;
		int leftChild = parent*2 + 1;
		int rightChild = parent*2 + 2;

		while(true)
		{
			//If leftChild is out of bounds stop
			if(leftChild >= arr.size()) break;

			//Check if it's less than left side
			if(arr.get(parent).compareTo(arr.get(leftChild)) < 0)
			{
				//If there's no right, swap and return
				if(rightChild >= arr.size())
				{
					swap(parent,leftChild);
					return retval;
				}
				//Otherwise compare left to right and choose the larger, and make new parent
				if(arr.get(leftChild).compareTo(arr.get(rightChild)) > 0)
				{
					swap(parent,leftChild);
					parent = leftChild;
					leftChild = 2*parent + 1;
					rightChild = 2*parent + 2;
					continue;
				}
				else
				{
					swap(parent,rightChild);
					parent = rightChild;
					leftChild = parent*2 + 1;
					rightChild = parent*2 + 2;
					continue;
				}
			}
			//If left isn't larger ,check if right even exists
			if(rightChild >= arr.size()) break;
			
			//If right exists, check if it's larger
			if(arr.get(parent).compareTo(arr.get(rightChild)) < 0)
			{
				swap(parent,rightChild);
				parent = rightChild;
				leftChild = parent*2 + 1;
				rightChild = parent*2 + 2;
				continue;
			}
			//Otherwise break and return
			break;
		}
		return retval;
	}
}
