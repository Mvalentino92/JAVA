import java.util.*;
public abstract class MyAbstractList<E> implements MyList<E>
{
	protected int size = 0;

	@Override 
	public int size()
	{
		return size;
	}

	@Override
	public boolean isEmpty()
	{
		return size == 0;
	}
	
	/*Add a new element to the end of the list
	@Override
	public boolean add(E e)
	{
		addLast(e);
		return true;
	}
	
	//Remove the element at the specified index
	@Override
	public E remove(int index)
	{
		//Check to see if out of bounds first
		checkIndex(index);
		E e = elements[index];

		//Shift all the elements
		for(int i = index; i < size - 1; i++)
		{
			elements[i] = elements[i+1];
		}

		//Set last to null, decrement size
		elements[size-1] = null;
		size--;

		return e;
	}*/
}
