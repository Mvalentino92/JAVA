import java.util.*;
public class MyLinkedList<E extends Comparable> extends MyAbstractList<E>
{
	private Link<E> head;
	private Link<E> tail;
	//private int size = 0;

	//Empty List
	public MyLinkedList(){}

	//Create from array of Objects
	public MyLinkedList(E[] array)
	{
		for(int i = 0; i < array.length; i++) add(array[i]);
	}

	//Return the head element
	public E getFirst()
	{
		if(size == 0) return null;
		else return head.element;
	}

	//Return the last element in the list
	public E getLast()
	{
		if(size == 0) return null;
		else return tail.element;
	}

	//Add an element to the beginning of the list
	public void addFirst(E e)
	{
		Link<E> newLink = new Link<>(e);
		newLink.next = head;
		head = newLink;
		size++;

		//If it's only node in the list
		if(tail == null) tail = head;
	}

	//Add an element to the end of the list (possibly override the add and just call that)
	public void addLast(E e)
	{
		Link<E> newLink = new Link<>(e);
		if(tail == null) head = tail = newLink;
		else
		{
			tail.next = newLink;
			tail = newLink;
		}
		size++;
	}

	//Add a new element at specified index
	@Override
	public void add(int index, E e)
	{
		if(index == 0) addFirst(e);
		else if(index >= size) addLast(e);
		else
		{
			Link<E> current = head;
			for(int i = 1; i < index; i++) current = current.next;
			Link<E> temp = current.next;
			current.next = new Link<>(e);
			(current.next).next = temp;
			size++;
		}
	}

	//Add a new element to the end of the list
	@Override
	public boolean add(E e)
	{
		addLast(e);
		return true;
	}

	//Remove the first element
	public E removeFirst()
	{
		if(size == 0) return null;
		else
		{
			Link<E> temp = head;
			head = head.next;
			size--;
			if(head == null) tail = null;
			return temp.element;
		}
	}

	//Remove the last element
	public E removeLast()
	{
		if(size == 0) return null;
		else if(size == 1)
		{
			Link<E> temp = head;
			head = tail = null;
			size = 0;
			return temp.element;
		}
		else
		{
			Link<E> current = head;
			for(int i = 0; i < size - 2; i++)
			{
				current = current.next;
			}
			Link<E> temp = tail;
			tail = current;
			tail.next = null;
			size--;
			return temp.element;
		}
	}

	//Remove element at the index
	@Override
	public E remove(int index)
	{
		if(index < 0 || index >= size) return null;
		else if(index == 0) return removeFirst();
		else if(index == size - 1) return removeLast();
		else
		{
			Link<E> previous = head;
			for(int i = 1; i < index; i++) previous = previous.next;
			Link<E> current = previous.next;
			previous.next = current.next;
			size--;
			return current.element;
		}
	}

	//Retrieves the element at the specified index
	@Override
	public E get(int index)
	{
		if(index < 0 || index >= size)
		{
			throw new IndexOutOfBoundsException
				("Index: "+index+", Size: "+size);
		}

		Link<E> current = head;
		for(int i = 0; i < index; i++) current = current.next;
		return current.element;
	}
			
	//Returns the index of the first occurance
	@Override
	public int indexOf(E e)
	{
		if(isEmpty()) return -1;
		Link<E> current = head;
		for(int i = 0; i < size; i++)
		{
			if((current.element).equals(e)) return i;
			current = current.next;
		}
		return -1;
	}

	//Returns the index of the last occurance
	@Override
	public int lastIndexOf(E e)
	{
		if(isEmpty()) return -1;
		Link<E> current = head;
		int retval = -1;
		for(int i = 0; i < size; i++)
		{
			if((current.element).equals(e)) retval = i;
			current = current.next;
		}
		return retval;
	}

	//Replaces old with new and returns old
	@Override
	public E set(int index, E e)
	{
		if(index < 0 || index >= size)
		{
			throw new IndexOutOfBoundsException
				("Index: "+index+", Size: "+size);
		}

		Link<E> current = head;
		for(int i = 0; i < index; i++) current = current.next;
		E retval = current.element;
		current.element = e;
		return retval;
	}

	public void iSort()
	{
		//Create new LinkedList
		Link<E> retval = new Link(this.removeFirst());
		int retSize = 1;

		while(size > 0)
		{
			//Get next element from List
			E current = this.removeFirst();
			Link<E> start = retval;
			Link<E> toAdd = new Link(current);
			boolean added = false;

			//Check first element first
			if(current.compareTo(start.element) < 0)
			{
				toAdd.next = start;
				retval = toAdd;
				retSize++;
				continue;
			}

			//Begin to iterate the retval List, and check it against element
			for(int i = 0; i < retSize - 1; i++)
			{
				if(current.compareTo((start.next).element) < 0)
				{
					added = true;
					break;
				}
				else start = start.next;
			}
			if(added)
			{
				Link<E> temp = start.next;
				start.next = toAdd;
				toAdd.next = temp;
			}
			else start.next = toAdd;
			retSize++;
		}
		head = retval;
		size = retSize;
	}
}

class Link<E>
{
	E element;
	Link<E> next;

	public Link(E e)
	{
		element = e;
	}
}
